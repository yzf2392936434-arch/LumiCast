package xiao.bu.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Build;
import xiao.bu.tv.AppLog;
import android.view.KeyEvent;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Locale;
import java.util.zip.ZipFile;

/** Checks release manifests, downloads a compatible APK, and opens the system installer. */
final class AutoUpdater {
    static final String POPUP_PREFERENCE = "update_popup_enabled";
    interface ManifestReader { String read(String url) throws IOException; }
    private static final String TAG = "AutoUpdater";
    private static final String IMPORTANT_VERSION_URL = "https://github.com/buhanzhe/NativeWasmTv/"
            + "releases/latest/download/version.json";
    private static final String LITE_VERSION_URL = "https://github.com/buhanzhe/NativeWasmTv/"
            + "releases/latest/download/version-lite.json";
    private static final int CONNECT_TIMEOUT_MS = 15000;
    private static final int READ_TIMEOUT_MS = 30000;
    private static final int MAX_MANIFEST_BYTES = 64 * 1024;
    private static final long MAX_APK_BYTES = 256L * 1024L * 1024L;

    private final Activity activity;
    private final ManifestReader manifestReader;
    private volatile boolean destroyed;
    private volatile Runnable liteListener;
    void setLiteListener(Runnable listener){liteListener=listener;}
    private void notifyLite(){notifyLite(null);}
    private void notifyLite(String message){activity.runOnUiThread(()->{
        if(destroyed||activity.isFinishing())return;
        Runnable value=liteListener;if(value!=null)value.run();
        if(message!=null)Toast.makeText(activity,message,Toast.LENGTH_LONG).show();
    });}
    private volatile boolean importantChecking;
    private volatile boolean liteChecking;
    private volatile String liteState = "idle";
    private volatile String liteMessage = "点击检查更新";
    private volatile int liteVersionCode;
    private volatile String liteVersionName = "";
    private volatile boolean liteArchitectureUpgrade;
    private volatile UpdateInfo liteUpdate;
    private volatile boolean downloadActive;
    private boolean promptShowing;
    private boolean optionalPrompt;
    private volatile UpdateInfo importantUpdate;
    private AlertDialog promptDialog;
    private ProgressDialog progressDialog;

    AutoUpdater(Activity activity) {
        this(activity, null);
    }

    AutoUpdater(Activity activity, ManifestReader reader) {
        this.activity = activity;
        this.manifestReader = reader;
    }

    static boolean officialBuild() {
        return "xiao.bu.tv".equals(BuildConfig.APPLICATION_ID);
    }

    private boolean upstreamUpdatesEnabled() {
        return officialBuild() || manifestReader != null;
    }

    static boolean popupEnabled(android.content.Context context) {
        if (!officialBuild()) return false;
        return context.getSharedPreferences(MainActivity.PREFERENCES, 0)
                .getBoolean(POPUP_PREFERENCE, false);
    }

    void popupPreferenceChanged(boolean enabled) {
        if (!enabled && optionalPrompt && promptDialog != null) promptDialog.dismiss();
    }

    void checkForUpdates() {
        if (!upstreamUpdatesEnabled() || importantChecking || destroyed) {
            return;
        }
        importantChecking = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                boolean importantAvailable = importantUpdate != null;
                try {
                    final UpdateInfo update = loadUpdateInfo(IMPORTANT_VERSION_URL, false);
                    if (destroyed) return;
                    if (update.versionCode <= BuildConfig.VERSION_CODE) {
                        importantUpdate = null;
                        importantAvailable = false;
                        return;
                    }
                    importantUpdate = update;
                    importantAvailable = true;
                    AppLog.i(TAG, "Update available: " + update.versionName + ", asset="
                            + update.apkAsset);
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (importantUpdate == update) showUpdatePrompt(update, false);
                        }
                    });
                } catch (Exception error) {
                    // Startup checks are intentionally silent when the device is offline.
                    AppLog.w(TAG, "Update check failed", error);
                } finally {
                    importantChecking = false;
                    // The important-version threshold always runs, even with
                    // optional notices disabled. Never stack a lite notice on it.
                    if (!importantAvailable && !destroyed && popupEnabled(activity))
                        checkLiteForUpdates(false, true);
                }
            }
        }, "update-check").start();
    }

    synchronized String checkLiteForUpdates() {return checkLiteForUpdates(false);}

    synchronized String checkLiteForUpdates(final boolean showResult) {
        return checkLiteForUpdates(showResult, false);
    }

    private synchronized String checkLiteForUpdates(final boolean showResult, final boolean popup) {
        if (!upstreamUpdatesEnabled()) return stateResponse(false, UiLanguage.text("请从本版本的发布渠道获取更新"));
        if (destroyed) return stateResponse(false, "更新服务已关闭");
        if (downloadActive || "downloading".equals(liteState)) return stateResponse(true, "正在下载更新");
        if (liteChecking) return stateResponse(true, "正在检查更新");
        liteUpdate = null;
        liteChecking = true;
        liteState = "checking";
        liteMessage = "正在检查更新…";
        liteVersionCode = 0;
        liteVersionName = "";
        liteArchitectureUpgrade = false;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final UpdateInfo update = loadUpdateInfo(LITE_VERSION_URL, true);
                    boolean newer = update.versionCode > BuildConfig.VERSION_CODE;
                    boolean architectureUpgrade = update.architectureUpgrade
                            && update.versionCode >= BuildConfig.VERSION_CODE;
                    liteVersionCode = update.versionCode;
                    liteVersionName = update.versionName;
                    liteArchitectureUpgrade = architectureUpgrade;
                    if (!newer && !architectureUpgrade) {
                        liteState = "current";
                        liteMessage = "已是最新版本";
                        return;
                    }
                    liteUpdate = update;
                    liteState = "available";
                    liteMessage = architectureUpgrade
                            ? "可升级到 64 位版本" : "发现新版本 " + update.versionName;
                    if (popup) activity.runOnUiThread(() -> {
                        if (popupEnabled(activity) && importantUpdate == null)
                            showUpdatePrompt(update, true);
                    });
                } catch (Exception error) {
                    liteState = "error";
                    liteMessage = "检查失败：" + readableMessage(error);
                    AppLog.w(TAG, "Lightweight update check failed", error);
                } finally {
                    liteChecking = false;
                    notifyLite(showResult ? liteMessage : null);
                }
            }
        }, "update-lite-check").start();
        notifyLite();return stateResponse(true, "正在检查更新");
    }

    synchronized String installLiteUpdate() {
        if (!upstreamUpdatesEnabled()) return stateResponse(false, UiLanguage.text("请从本版本的发布渠道获取更新"));
        if (destroyed) return stateResponse(false, "更新服务已关闭");
        if (downloadActive || "downloading".equals(liteState)) return stateResponse(true, "正在下载更新");
        final UpdateInfo update = liteUpdate;
        if (liteChecking || update == null || !("available".equals(liteState) || "ready".equals(liteState)))
            return stateResponse(false, "请先检查更新");
        liteState = "downloading";
        liteMessage = "正在下载更新…";
        activity.runOnUiThread(new Runnable() {
            @Override public void run() {
                if (destroyed || activity.isFinishing()) return;
                // The system-information page owns confirmation and progress for manual updates.
                downloadUpdate(update, false);
            }
        });
        return stateResponse(true, liteMessage);
    }

    JSONObject stateJson() {
        JSONObject result = new JSONObject();
        try {
            result.put("state", liteState);
            result.put("checking", liteChecking);
            result.put("message", upstreamUpdatesEnabled() ? liteMessage : UiLanguage.text("请从本版本的发布渠道获取更新"));
            result.put("versionCode", liteVersionCode);
            result.put("versionName", liteVersionName);
            result.put("architectureUpgrade", liteArchitectureUpgrade);
            result.put("installed64Bit", is64BitBuild());
            result.put("supports64Bit", supports64Bit());
        } catch (JSONException ignored) {
        }
        return result;
    }

    private String stateResponse(boolean ok, String message) {
        JSONObject result = new JSONObject();
        try {
            result.put("ok", ok);
            result.put("message", message);
            result.put("update", stateJson());
        } catch (JSONException ignored) {
        }
        return result.toString();
    }

    void destroy() {
        destroyed = true;liteListener=null;
        if (promptDialog != null) {
            promptDialog.dismiss();
            promptDialog = null;
        }
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    private UpdateInfo loadUpdateInfo(String manifestUrl, boolean allowArchitectureUpgrade)
            throws IOException, JSONException {
        String json = manifestReader == null ? readManifest(manifestUrl) : manifestReader.read(manifestUrl);

        JSONObject object = new JSONObject(json);
        return parseUpdateInfo(object, allowArchitectureUpgrade);
    }

    String readManifest(String manifestUrl) throws IOException {
        try {
            return readManifestOnce(manifestUrl);
        } catch (HttpStatusException error) {
            if (error.status != HttpURLConnection.HTTP_NOT_FOUND) throw error;
            URL original = new URL(manifestUrl.trim());
            if (!original.getPath().endsWith("/version-lite.json")) throw error;
            // Older releases only publish version.json. Keep the same release
            // path and caller query; never treat other HTTP failures as absence.
            String query = original.getQuery();
            String fallback = new URL(original, "version.json"
                    + (query == null ? "" : "?" + query)).toExternalForm();
            return readManifestOnce(fallback);
        }
    }

    private String readManifestOnce(String manifestUrl) throws IOException {
        // Keep the canonical URL here. NetworkClient owns accelerator selection
        // and failover; query parameters must never be appended to an empty route.
        HttpURLConnection connection = openConnection(
                manifestRequestUrl(manifestUrl, System.currentTimeMillis()));
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("Cache-Control", "no-cache");
        try {
            requireSuccessful(connection);
            InputStream input = new BufferedInputStream(connection.getInputStream());
            try {
                return readUtf8(input, MAX_MANIFEST_BYTES);
            } finally {
                input.close();
            }
        } finally {
            connection.disconnect();
        }

    }

    static String manifestRequestUrl(String manifestUrl, long timestamp) throws IOException {
        String address = manifestUrl == null ? "" : manifestUrl.trim();
        if (address.length() == 0) throw new IOException("更新地址为空，无法检查更新");
        if (!(address.regionMatches(true, 0, "https://", 0, 8)
                || address.regionMatches(true, 0, "http://", 0, 7))) {
            throw new IOException("更新地址无效，需要完整的 HTTP/HTTPS 地址");
        }
        try {
            URL parsed = new URL(address);
            if (parsed.getHost().length() == 0 || parsed.getUserInfo() != null
                    || parsed.getPort() == 0 || parsed.getPort() > 65535) {
                throw new IOException("更新地址无效");
            }
            parsed.toURI();
        } catch (java.net.MalformedURLException | java.net.URISyntaxException error) {
            throw new IOException("更新地址格式不正确", error);
        }
        int fragment = address.indexOf('#');
        if (fragment >= 0) address = address.substring(0, fragment);
        String separator = address.endsWith("?") || address.endsWith("&") ? ""
                : address.indexOf('?') >= 0 ? "&" : "?";
        return address + separator + "_=" + timestamp;
    }

    private UpdateInfo parseUpdateInfo(JSONObject object, boolean allowArchitectureUpgrade)
            throws JSONException {
        int versionCode = object.getInt("versionCode");
        String versionName = object.getString("versionName").trim();
        boolean architectureUpgrade = allowArchitectureUpgrade
                && isArm32Build() && supportsArm64(Build.VERSION.SDK_INT >= 21
                        ? Build.SUPPORTED_64_BIT_ABIS : null);
        String urlField = architectureUpgrade ? "apk64Url" : BuildConfig.UPDATE_APK_URL_FIELD;
        String shaField = architectureUpgrade ? "sha25664" : BuildConfig.UPDATE_SHA256_FIELD;
        String apkAsset = architectureUpgrade ? "nTv64.apk" : BuildConfig.UPDATE_APK_ASSET;
        String apkUrl = object.optString(urlField, "").trim();
        String sha256 = object.optString(shaField, "")
                .trim().toLowerCase(Locale.US);
        String releaseNotes = object.optString("releaseNotes", "").trim();
        if (versionCode < 1 || versionName.length() == 0) {
            throw new JSONException("Invalid version metadata");
        }
        if (apkUrl.length() == 0) {
            throw new JSONException("Missing APK URL for " + apkAsset);
        }
        apkUrl = validatedGithubUrl(apkUrl);
        String displayAsset = "ntvFull".equals(BuildConfig.FLAVOR) ? "网页电视全量.apk"
                : architectureUpgrade || "arm64".equals(BuildConfig.FLAVOR) || "ntvBro64".equals(BuildConfig.FLAVOR)
                ? "网页电视64位.apk" : "x86".equals(BuildConfig.FLAVOR)
                ? "网页电视x86.apk" : "网页电视32位.apk";
        apkAsset = validatedApkFilename(apkUrl, apkAsset, displayAsset);
        if (!sha256.matches("[0-9a-f]{64}")) {
            throw new JSONException("Invalid APK SHA-256");
        }
        return new UpdateInfo(versionCode, versionName, apkUrl, sha256, releaseNotes,
                apkAsset, architectureUpgrade);
    }

    static String validatedApkFilename(String apkUrl, String expected, String displayAsset)
            throws JSONException {
        try {
            String path = new URL(apkUrl).getPath();
            String file = java.net.URLDecoder.decode(path.substring(path.lastIndexOf('/') + 1), "UTF-8");
            if (!file.equalsIgnoreCase(expected) && !file.equals(displayAsset)) {
                throw new JSONException("Wrong APK URL for " + expected);
            }
            // Preserve the manifest's case: GitHub asset paths are case-sensitive.
            return file;
        } catch (IOException | IllegalArgumentException error) {
            throw new JSONException("Invalid APK filename");
        }
    }

    static boolean supportsArm64(String[] abis) {
        if (abis != null) for (String abi : abis) if ("arm64-v8a".equals(abi)) return true;
        return false;
    }

    private static boolean isArm32Build() {
        return "arm32".equals(BuildConfig.FLAVOR);
    }

    private static boolean is64BitBuild() {
        return "arm64".equals(BuildConfig.FLAVOR);
    }

    private static boolean supports64Bit() {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
                && Build.SUPPORTED_64_BIT_ABIS != null
                && Build.SUPPORTED_64_BIT_ABIS.length > 0;
    }

    private void showUpdatePrompt(final UpdateInfo update, boolean optional) {
        if (optional && (!popupEnabled(activity) || importantUpdate != null)) return;
        if (!optional && optionalPrompt && promptDialog != null) promptDialog.dismiss();
        if (!canShowDialog() || promptShowing || downloadActive) {
            return;
        }
        promptShowing = true;
        optionalPrompt = optional;
        String notes = update.releaseNotes.length() == 0 ? "包含功能改进和问题修复。"
                : update.releaseNotes;
        String title = update.architectureUpgrade
                && update.versionCode == BuildConfig.VERSION_CODE
                ? activity.getString(R.string.update_64bit_title)
                : activity.getString(R.string.update_available_title, update.versionName);
        String message = activity.getString(R.string.update_available_message,
                BuildConfig.VERSION_NAME, update.versionName, notes);
        if (update.architectureUpgrade) {
            message += "\n\n" + activity.getString(R.string.update_64bit_notice);
        }
        final AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(title)
                .setMessage(message)
                .setPositiveButton(R.string.update_now, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        promptShowing = false;
                        downloadUpdate(update);
                    }
                })
                .setNegativeButton(R.string.update_later, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int which) {
                        promptShowing = false;
                    }
                })
                .create();
        promptDialog = dialog;
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.setOnKeyListener(new DialogInterface.OnKeyListener() {
            @Override
            public boolean onKey(DialogInterface dialogInterface, int keyCode,
                    KeyEvent event) {
                if (keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.getAction() == KeyEvent.ACTION_UP) {
                        dialogInterface.dismiss();
                    }
                    return true;
                }
                return false;
            }
        });
        dialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
            @Override
            public void onCancel(DialogInterface dialogInterface) {
                promptShowing = false;
            }
        });
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override
            public void onDismiss(DialogInterface dialogInterface) {
                promptShowing = false;
                if (promptDialog == dialog) {
                    promptDialog = null;
                }
            }
        });
        if(!showDialog(dialog)){promptShowing=false;promptDialog=null;}
    }

    private boolean canShowDialog(){
        return !destroyed&&!activity.isFinishing()
                &&(Build.VERSION.SDK_INT<17||!activity.isDestroyed())
                &&activity.getWindow()!=null&&activity.getWindow().getDecorView().getWindowToken()!=null;
    }
    private boolean showDialog(android.app.Dialog dialog){
        if(!canShowDialog())return false;
        try{dialog.show();return true;}
        catch(android.view.WindowManager.BadTokenException|IllegalStateException stale){
            AppLog.w("AutoUpdater","Activity window unavailable for update dialog",stale);return false;
        }
    }

    private void downloadUpdate(final UpdateInfo update) {
        downloadUpdate(update, true);
    }

    private void downloadUpdate(final UpdateInfo update, boolean showProgress) {
        if (destroyed || downloadActive) return;
        downloadActive = true;
        if (showProgress) {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setTitle(R.string.update_downloading);
        progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.setMax(100);
        if(!showDialog(progressDialog))progressDialog=null;
        }

        new Thread(new Runnable() {
            @Override
            public void run() {
                File partial = null;
                try {
                    File directory = ApkFileProvider.updateDirectory(activity);
                    if (directory == null || (!directory.isDirectory() && !directory.mkdirs())) {
                        throw new IOException("无法创建更新目录");
                    }
                    File apk = new File(directory, update.apkAsset
                            .replace(".apk", "-" + update.versionCode + ".apk"));
                    if (apk.isFile() && verifySha256(apk, update.sha256) && isApk(apk)) {
                        validateUpdatePackage(apk);
                        finishDownload(apk);
                        return;
                    }
                    partial = new File(directory, apk.getName() + ".part");
                    if (partial.exists() && !partial.delete()) {
                        throw new IOException("无法清理旧的临时文件");
                    }
                    download(update.apkUrl, partial);
                    if (!verifySha256(partial, update.sha256)) {
                        throw new IOException("APK 完整性校验失败");
                    }
                    if (!isApk(partial)) {
                        throw new IOException("下载内容不是有效的 APK");
                    }
                    validateUpdatePackage(partial);
                    if (apk.exists() && !apk.delete()) {
                        throw new IOException("无法替换旧的更新文件");
                    }
                    if (!partial.renameTo(apk)) {
                        copyFile(partial, apk);
                        if (!partial.delete()) {
                            AppLog.w(TAG, "Unable to remove partial APK " + partial);
                        }
                    }
                    finishDownload(apk);
                } catch (final Exception error) {
                    downloadActive = false;
                    if ("downloading".equals(liteState)) {
                        liteState = "error";
                        liteMessage = "下载失败：" + readableMessage(error);
                    }
                    notifyLite();
                    AppLog.e(TAG, "Update download failed", error);
                    if (partial != null && partial.exists() && !partial.delete()) {
                        AppLog.w(TAG, "Unable to remove failed partial APK " + partial);
                    }
                    activity.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            dismissProgress();
                            if (!destroyed) {
                                Toast.makeText(activity,
                                        activity.getString(R.string.update_download_failed,
                                                readableMessage(error)), Toast.LENGTH_LONG).show();
                            }
                        }
                    });
                }
            }
        }, "update-download").start();
    }

    private void download(String url, File destination) throws IOException {
        HttpURLConnection connection = openConnection(url);
        try {
            requireSuccessful(connection);
            final long length = contentLength(connection);
            if (length > MAX_APK_BYTES) {
                throw new IOException("APK 文件过大");
            }
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (progressDialog != null) {
                        progressDialog.setIndeterminate(length <= 0L);
                    }
                }
            });
            InputStream input = new BufferedInputStream(connection.getInputStream());
            FileOutputStream output = new FileOutputStream(destination);
            try {
                byte[] buffer = new byte[64 * 1024];
                long total = 0L;
                int lastProgress = -1;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (destroyed) {
                        throw new IOException("下载已取消");
                    }
                    total += count;
                    if (total > MAX_APK_BYTES) {
                        throw new IOException("APK 文件过大");
                    }
                    output.write(buffer, 0, count);
                    if (length > 0L) {
                        final int progress = (int) Math.min(100L, total * 100L / length);
                        if (progress != lastProgress) {
                            lastProgress = progress;
                            if ("downloading".equals(liteState)) liteMessage = "正在下载更新 " + progress + "%";
                            activity.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    if (progressDialog != null) {
                                        progressDialog.setProgress(progress);
                                    }
                                }
                            });
                        }
                    }
                }
                if (length >= 0 && total != length) throw new IOException("APK 下载不完整，请重试");
                output.getFD().sync();
            } finally {
                try {
                    output.close();
                } finally {
                    input.close();
                }
            }
        } finally {
            connection.disconnect();
        }
    }

    private void validateUpdatePackage(File apk) throws IOException {
        android.content.pm.PackageInfo info = activity.getPackageManager()
                .getPackageArchiveInfo(apk.getAbsolutePath(), 0);
        if (info == null || !activity.getPackageName().equals(info.packageName)) {
            throw new IOException("更新包与当前应用不匹配，请检查发布文件");
        }
        // The manifest code controls prompting; the APK code controls installation.
        if (info.versionCode < BuildConfig.VERSION_CODE) {
            throw new IOException("更新包版本低于当前版本，请检查发布文件");
        }
    }

    private void finishDownload(final File apk) {
        downloadActive = false;
        if ("downloading".equals(liteState)) {
            liteState = "ready";
            liteMessage = "下载完成，请在设备上完成安装";
        }
        notifyLite();
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                dismissProgress();
                if (!destroyed) {
                    install(apk);
                }
            }
        });
    }

    private void install(final File apk) {
        launchInstaller(apk);
    }

    private void launchInstaller(File apk) {
        try {
            ApkTransferInstaller.launchInstaller(activity, apk);
        } catch (Exception error) {
            if ("ready".equals(liteState)) {
                liteMessage = "无法打开安装器：" + readableMessage(error) + "，可重试安装";
                notifyLite();
            }
            AppLog.e(TAG, "Unable to launch package installer", error);
            Toast.makeText(activity, R.string.update_install_failed, Toast.LENGTH_LONG).show();
        }
    }

    private void dismissProgress() {
        if (progressDialog != null) {
            progressDialog.dismiss();
            progressDialog = null;
        }
    }

    private static HttpURLConnection openConnection(String url) throws IOException {
        HttpURLConnection connection = NetworkClient.open(new URL(url));
        connection.setConnectTimeout(CONNECT_TIMEOUT_MS);
        connection.setReadTimeout(READ_TIMEOUT_MS);
        connection.setInstanceFollowRedirects(true);
        connection.setUseCaches(false);
        connection.setRequestProperty("Accept-Encoding", "identity");
        connection.setRequestProperty("User-Agent", "nTv/" + BuildConfig.VERSION_NAME
                + " Android/" + Build.VERSION.RELEASE);
        return connection;
    }

    private static void requireSuccessful(HttpURLConnection connection) throws IOException {
        int status = connection.getResponseCode();
        if (status < 200 || status >= 300) {
            throw new HttpStatusException(status);
        }
    }

    private static final class HttpStatusException extends IOException {
        final int status;
        HttpStatusException(int status) {
            super("HTTP " + status);
            this.status = status;
        }
    }

    private static long contentLength(HttpURLConnection connection) {
        String value = connection.getHeaderField("Content-Length");
        if (value == null) {
            return -1L;
        }
        try {
            return Long.parseLong(value);
        } catch (NumberFormatException ignored) {
            return -1L;
        }
    }

    private String validatedGithubUrl(String url) throws JSONException {
        try {
            URL parsed = new URL(url);
            String host = parsed.getHost().toLowerCase(Locale.US);
            if (!"https".equalsIgnoreCase(parsed.getProtocol())
                    || !("github.com".equals(host)
                    || "raw.githubusercontent.com".equals(host))) {
                throw new JSONException("APK URL must be an HTTPS GitHub URL");
            }
            return url; // NetworkClient applies the current GitHub route at request time.
        } catch (IOException error) {
            throw new JSONException("Invalid APK URL");
        }
    }

    private static String readUtf8(InputStream input, int limit) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(input, "UTF-8"));
        StringBuilder text = new StringBuilder();
        char[] buffer = new char[2048];
        int count;
        while ((count = reader.read(buffer)) != -1) {
            if (text.length() + count > limit) {
                throw new IOException("版本文件过大");
            }
            text.append(buffer, 0, count);
        }
        return text.toString();
    }

    private static boolean verifySha256(File file, String expected)
            throws IOException, NoSuchAlgorithmException {
        if (expected == null || !expected.matches("[0-9a-f]{64}")) {
            return false;
        }
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        InputStream input = new BufferedInputStream(new FileInputStream(file));
        try {
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) {
                digest.update(buffer, 0, count);
            }
        } finally {
            input.close();
        }
        byte[] hash = digest.digest();
        StringBuilder actual = new StringBuilder(hash.length * 2);
        for (byte value : hash) {
            actual.append(String.format(Locale.US, "%02x", value & 0xff));
        }
        return expected.equals(actual.toString());
    }

    private static boolean isApk(File file) {
        ZipFile zip = null;
        try {
            zip = new ZipFile(file);
            return zip.getEntry("AndroidManifest.xml") != null;
        } catch (IOException error) {
            return false;
        } finally {
            if (zip != null) {
                try {
                    zip.close();
                } catch (IOException ignored) {
                }
            }
        }
    }

    private static void copyFile(File source, File destination) throws IOException {
        InputStream input = new BufferedInputStream(new FileInputStream(source));
        FileOutputStream output = new FileOutputStream(destination);
        try {
            byte[] buffer = new byte[64 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) {
                output.write(buffer, 0, count);
            }
            output.getFD().sync();
        } finally {
            try {
                output.close();
            } finally {
                input.close();
            }
        }
    }

    private static String readableMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.length() == 0
                ? error.getClass().getSimpleName() : message;
    }

    private static final class UpdateInfo {
        final int versionCode;
        final String versionName;
        final String apkUrl;
        final String sha256;
        final String releaseNotes;
        final String apkAsset;
        final boolean architectureUpgrade;

        UpdateInfo(int versionCode, String versionName, String apkUrl,
                String sha256, String releaseNotes, String apkAsset,
                boolean architectureUpgrade) {
            this.versionCode = versionCode;
            this.versionName = versionName;
            this.apkUrl = apkUrl;
            this.sha256 = sha256;
            this.releaseNotes = releaseNotes;
            this.apkAsset = apkAsset;
            this.architectureUpgrade = architectureUpgrade;
        }
    }
}
