package xiao.bu.tv;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import static xiao.bu.tv.PhonePlayerControls.ACCENT;
import static xiao.bu.tv.PhonePlayerControls.LINE;
import static xiao.bu.tv.PhonePlayerControls.MUTED;
import static xiao.bu.tv.PhonePlayerControls.PANEL;
import static xiao.bu.tv.PhonePlayerControls.TILE;
import static xiao.bu.tv.PhonePlayerControls.dp;
import static xiao.bu.tv.PhonePlayerControls.label;
import static xiao.bu.tv.PhonePlayerControls.rounded;

/** Country groups use the bundled directory and retain the main player's own playlists. */
@SuppressWarnings("deprecation")
final class PhoneChannelPicker extends Dialog {
    private static final String CHINA = "CN";

    interface Host {
        boolean visitGroup(int group);
        void unlockGroup(int group, Runnable refresh);
        void play(int group, int channel);
        void playCountry(WorldChannelCatalog.Station station, List<WorldChannelCatalog.Station> members);
        boolean isFavorite(ChannelCatalog.Group group, Channel channel);
        boolean isCountryFavorite(WorldChannelCatalog.Station station);
        void toggleFavorite(int group, int channel);
        void toggleCountryFavorite(WorldChannelCatalog.Station station);
    }

    private static final class Choice {
        final int nativeGroup;
        final String country;

        Choice(int nativeGroup, String country) {
            this.nativeGroup = nativeGroup;
            this.country = country;
        }

        boolean isCountry() { return nativeGroup < 0; }

        boolean same(Choice other) {
            return nativeGroup == other.nativeGroup && country.equals(other.country);
        }
    }

    private static final class LocalRow {
        final int group, channel;

        LocalRow(int group, int channel) {
            this.group = group;
            this.channel = channel;
        }
    }

    private ChannelCatalog.Group[] groups;
    private final Host host;
    private int playingGroup, playingChannel;
    private WorldChannelCatalog.Station playingStation;
    private final Locale locale;
    private Choice selected;
    private WorldChannelCatalog.Index directory;
    private boolean directoryFailed;
    private LinearLayout sheet;
    private TextView groupButton, empty, clearSearch;
    private EditText query;
    private boolean groupLocked;
    private ListView channelList;
    private SearchableChoiceDialog groupDialog;

    PhoneChannelPicker(Context context, ChannelCatalog.Group[] groups, int group, int channel,
            WorldChannelCatalog.Station playingStation, Host host) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.groups = groups;
        this.host = host;
        this.playingStation = playingStation;
        playingGroup = group;
        playingChannel = channel;
        locale = context.getResources().getConfiguration().locale;
        if (playingStation != null) selected = new Choice(-1, playingStation.country);
        else if (group >= 0 && group < groups.length && !isChina(groups[group]))
            selected = new Choice(group, "");
        else selected = new Choice(-1, CHINA);
    }

    private static boolean isChina(ChannelCatalog.Group group) {
        if (!group.password.isEmpty()) return false;
        return group.source == ChannelCatalog.SOURCE_CCTV_WEB
                || group.source == ChannelCatalog.SOURCE_YSP_CCTV
                || group.source == ChannelCatalog.SOURCE_YSP_SATELLITE
                || (group.source == ChannelCatalog.SOURCE_CUSTOM && group.playlistSourceId.isEmpty()
                    && ("央视频道".equals(group.title) || "卫视频道".equals(group.title)));
    }

    @Override protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        Context context = getContext();
        sheet = new LinearLayout(context);
        sheet.setOrientation(LinearLayout.VERTICAL);
        sheet.setPadding(dp(sheet, 16), dp(sheet, 12), dp(sheet, 16), dp(sheet, 12));
        sheet.setBackgroundDrawable(rounded(context, PANEL, 20));
        sheet.setFocusableInTouchMode(true);

        LinearLayout header = new LinearLayout(context);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label(context, 23, Color.WHITE);
        title.setText(R.string.phone_pick);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        TextView close = action(R.string.phone_close, false);
        close.setOnClickListener(view -> dismiss());
        header.addView(close);
        sheet.addView(header, new LinearLayout.LayoutParams(-1, -2));

        groupButton = action(R.string.phone_multilingual, true);
        groupButton.setId(R.id.phone_group_picker);
        groupButton.setOnClickListener(view -> showGroups());
        LinearLayout.LayoutParams groupLayout = new LinearLayout.LayoutParams(-1, -2);
        groupLayout.topMargin = dp(sheet, 6);
        groupLayout.bottomMargin = dp(sheet, 8);
        sheet.addView(groupButton, groupLayout);

        LinearLayout search = new LinearLayout(context);
        search.setGravity(Gravity.CENTER_VERTICAL);
        search.setBackgroundDrawable(rounded(context, TILE, 12));
        query = new EditText(context);
        query.setId(R.id.phone_channel_search);
        query.setHint(R.string.phone_channel_search);
        query.setTextColor(Color.WHITE);
        query.setHintTextColor(MUTED);
        query.setTextSize(16);
        query.setSingleLine(true);
        query.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});
        query.setInputType(InputType.TYPE_CLASS_TEXT);
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        query.setPadding(dp(sheet, 12), 0, dp(sheet, 4), 0);
        query.setBackgroundColor(Color.TRANSPARENT);
        query.setOnEditorActionListener((view, action, event) -> {
            if (action != EditorInfo.IME_ACTION_SEARCH) return false;
            hideKeyboard();
            return true;
        });
        search.addView(query, new LinearLayout.LayoutParams(0, dp(sheet, 50), 1));
        clearSearch = label(context, 26, ACCENT);
        clearSearch.setId(R.id.phone_channel_clear);
        clearSearch.setText("×");
        clearSearch.setGravity(Gravity.CENTER);
        clearSearch.setFocusable(true);
        clearSearch.setContentDescription(context.getText(R.string.phone_clear_search));
        clearSearch.setOnClickListener(view -> query.setText(""));
        search.addView(clearSearch, new LinearLayout.LayoutParams(dp(sheet, 48), dp(sheet, 50)));
        LinearLayout.LayoutParams searchLayout = new LinearLayout.LayoutParams(-1, -2);
        searchLayout.bottomMargin = dp(sheet, 8);
        sheet.addView(search, searchLayout);

        channelList = new ListView(context);
        channelList.setId(R.id.phone_channel_list);
        channelList.setDivider(new ColorDrawable(LINE));
        channelList.setDividerHeight(dp(sheet, 1));
        channelList.setOnItemClickListener((parent, view, position, id) -> ((Rows) parent.getAdapter()).play(position));
        channelList.setOnItemLongClickListener((parent, view, position, id) -> {
            Rows rows = (Rows) parent.getAdapter();
            rows.toggleFavorite(rows.visible.get(position));
            return true;
        });
        sheet.addView(channelList, new LinearLayout.LayoutParams(-1, 0, 1));

        empty = label(context, 15, MUTED);
        empty.setId(R.id.phone_channel_empty);
        empty.setGravity(Gravity.CENTER);
        empty.setPadding(dp(sheet, 10), dp(sheet, 12), dp(sheet, 10), dp(sheet, 12));
        sheet.addView(empty, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(sheet);
        query.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence text, int start, int count, int after) { }
            public void onTextChanged(CharSequence text, int start, int before, int count) { updateResults(); }
            public void afterTextChanged(Editable text) { }
        });
        sheet.requestFocus();
        renderGroup();
        Context app = context.getApplicationContext();
        new Thread(() -> {
            WorldChannelCatalog.Index loaded = null;
            try { loaded = WorldChannelCatalog.load(app); }
            catch (Exception error) { AppLog.w("PhoneChannelPicker", "Could not load country groups", error); }
            WorldChannelCatalog.Index result = loaded;
            sheet.post(() -> {
                if (!isShowing()) return;
                directory = result;
                directoryFailed = result == null;
                if (selected.isCountry()) renderGroup();
                if (groupDialog != null && groupDialog.isShowing()) showGroups();
            });
        }, "phone-country-directory").start();
    }

    @Override protected void onStart() {
        super.onStart();
        updateWindowSize();
    }

    void updateWindowSize() {
        Window window = getWindow();
        if (window == null || sheet == null) return;
        android.util.DisplayMetrics screen = getContext().getResources().getDisplayMetrics();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        int width = Math.min(screen.widthPixels - dp(sheet, 24), dp(sheet, 550));
        int height = Math.min(screen.heightPixels - dp(sheet, 32), dp(sheet, 620));
        window.setLayout(Math.max(1, width), Math.max(1, height));
        if (groupDialog != null && groupDialog.isShowing()) groupDialog.updateWindowSize();
    }

    private TextView action(int resource, boolean filled) {
        TextView text = label(getContext(), 14, filled ? ACCENT : MUTED);
        text.setText(resource);
        text.setGravity(filled ? Gravity.CENTER_VERTICAL : Gravity.CENTER);
        text.setMinimumHeight(dp(sheet, 48));
        text.setPadding(dp(sheet, 12), dp(sheet, 4), dp(sheet, 12), dp(sheet, 4));
        text.setFocusable(true);
        if (filled) text.setBackgroundDrawable(rounded(getContext(), TILE, 12));
        return text;
    }

    private String name(Choice choice) {
        return choice.isCountry() ? WorldChannelCatalog.countryName(choice.country, locale)
                : UiLanguage.text(groups[choice.nativeGroup].displayTitle);
    }

    void showGroups() {
        hideKeyboard();
        List<Choice> choices = new ArrayList<>();
        List<String> countries = new ArrayList<>(directory == null
                ? WorldChannelCatalog.countryCodes() : directory.countries);
        Collator sorting = Collator.getInstance(locale);
        Collections.sort(countries, (left, right) -> sorting.compare(
                WorldChannelCatalog.countryName(left, locale), WorldChannelCatalog.countryName(right, locale)));
        for (String code : countries) choices.add(new Choice(-1, code));
        for (int group = 0; group < groups.length; group++)
            if (!isChina(groups[group])) choices.add(new Choice(group, ""));
        List<SearchableChoiceDialog.Choice> searchable = new ArrayList<>();
        int checked = -1;
        for (int i = 0; i < choices.size(); i++) {
            Choice choice = choices.get(i);
            String label = name(choice);
            String aliases = choice.isCountry() ? WorldChannelCatalog.countrySearchText(choice.country)
                    : groups[choice.nativeGroup].displayTitle;
            searchable.add(new SearchableChoiceDialog.Choice(i, label, label + " " + aliases));
            if (choice.same(selected)) checked = i;
        }
        String heading = getContext().getString(R.string.phone_country_groups, countries.size());
        SearchableChoiceDialog.Listener listener = index -> {
            query.setText("");
            selected = choices.get(index);
            renderGroup();
        };
        if (groupDialog != null && groupDialog.isShowing()) {
            groupDialog.updateChoices(heading, searchable, checked, listener);
        } else {
            groupDialog = new SearchableChoiceDialog(getContext(), heading, searchable, checked, listener);
            groupDialog.show();
        }
    }

    private void renderGroup() {
        groupButton.setText(getContext().getString(selected.isCountry()
                ? R.string.phone_multilingual_group : R.string.phone_group_name, name(selected)));
        groupLocked = !selected.isCountry() && !host.visitGroup(selected.nativeGroup);
        query.setEnabled(!groupLocked);
        clearSearch.setEnabled(!groupLocked);
        channelList.setAdapter(groupLocked ? null : new Rows(selected));
        updateResults();
    }

    ChannelCatalog.Group[] catalog() { return groups; }

    void refreshFavorites(ChannelCatalog.Group[] next, int playingGroup, int playingChannel,
            WorldChannelCatalog.Station playingStation) {
        int first = channelList.getFirstVisiblePosition();
        View firstRow = channelList.getChildAt(0);
        int top = firstRow == null ? 0 : firstRow.getTop();
        ChannelCatalog.Group previous = selected.isCountry() ? null : groups[selected.nativeGroup];
        groups = next;
        this.playingGroup = playingGroup;
        this.playingChannel = playingChannel;
        this.playingStation = playingStation;
        if (previous != null) {
            selected = new Choice(-1, CHINA);
            for (int index = 0; index < groups.length; index++) {
                ChannelCatalog.Group candidate = groups[index];
                if (candidate.source == previous.source && TextUtils.equals(candidate.title, previous.title)
                        && TextUtils.equals(candidate.playlistSourceId, previous.playlistSourceId)) {
                    selected = new Choice(index, "");
                    break;
                }
            }
        }
        renderGroup();
        if (channelList.getCount() > 0)
            channelList.setSelectionFromTop(Math.min(first, channelList.getCount() - 1), top);
        if (groupDialog != null && groupDialog.isShowing()) showGroups();
    }

    private void updateResults() {
        String word = WorldChannelCatalog.key(query.getText().toString());
        clearSearch.setVisibility(query.length() == 0 ? View.INVISIBLE : View.VISIBLE);
        Rows rows = (Rows) channelList.getAdapter();
        if (rows != null) rows.filter(word);
        boolean hasChannels = rows != null && rows.getCount() > 0;
        channelList.setVisibility(hasChannels ? View.VISIBLE : View.GONE);
        empty.setVisibility(hasChannels ? View.GONE : View.VISIBLE);
        if (hasChannels) {
            int current = rows.selectedPosition();
            channelList.setSelection(word.isEmpty() && current >= 0 ? current : 0);
        } else {
            int message = R.string.phone_empty_group;
            if (groupLocked) message = R.string.phone_unlock_group;
            else if (rows != null && rows.totalCount() > 0 && !word.isEmpty()) message = R.string.phone_world_empty;
            else if (!selected.isCountry() && groups[selected.nativeGroup].source == ChannelCatalog.SOURCE_FAVORITES)
                message = R.string.phone_favorites_empty;
            else if (selected.isCountry() && directory == null)
                message = directoryFailed ? R.string.phone_world_update_error : R.string.phone_world_loading;
            else if (selected.isCountry()) message = R.string.phone_country_empty;
            empty.setText(message);
            empty.setTextColor(groupLocked ? ACCENT : MUTED);
            empty.setOnClickListener(groupLocked ? view -> host.unlockGroup(selected.nativeGroup, this::renderGroup) : null);
            empty.setClickable(groupLocked);
        }
    }

    private void hideKeyboard() {
        InputMethodManager keyboard = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (keyboard != null && query != null) keyboard.hideSoftInputFromWindow(query.getWindowToken(), 0);
    }

    @Override public void dismiss() {
        if (groupDialog != null && groupDialog.isShowing()) groupDialog.dismiss();
        hideKeyboard();
        super.dismiss();
    }

    private final class Rows extends BaseAdapter {
        private final ArrayList<LocalRow> local = new ArrayList<>();
        private final List<WorldChannelCatalog.Station> world;
        private final ArrayList<String> searchKeys = new ArrayList<>();
        private final ArrayList<String> numbers = new ArrayList<>();
        private final ArrayList<Integer> visible = new ArrayList<>();

        Rows(Choice selection) {
            if (!selection.isCountry()) {
                addLocalGroup(selection.nativeGroup);
            } else if (CHINA.equals(selection.country)) {
                for (int i = 0; i < groups.length; i++) if (isChina(groups[i])) addLocalGroup(i);
            }
            world = selection.isCountry() && directory != null
                    ? directory.forCountry(selection.country) : new ArrayList<>();
            if (!local.isEmpty() && !world.isEmpty()) {
                Set<String> localNames = new HashSet<>();
                for (LocalRow row : local)
                    localNames.add(WorldChannelCatalog.key(groups[row.group].channels[row.channel].name));
                for (int i = world.size() - 1; i >= 0; i--) {
                    WorldChannelCatalog.Station station = world.get(i);
                    boolean duplicate = localNames.contains(WorldChannelCatalog.key(station.name));
                    for (String alternative : station.alternateNames)
                        duplicate |= localNames.contains(WorldChannelCatalog.key(alternative));
                    if (duplicate) world.remove(i);
                }
            }
            for (int position = 0; position < totalCount(); position++) {
                numbers.add(channelNumber(position));
                if (position < local.size()) {
                    LocalRow row = local.get(position);
                    Channel channel = groups[row.group].channels[row.channel];
                    searchKeys.add(WorldChannelCatalog.key(channel.name));
                } else searchKeys.add(world.get(position - local.size()).searchKey());
            }
        }

        private void addLocalGroup(int group) {
            for (int channel = 0; channel < groups[group].channels.length; channel++)
                local.add(new LocalRow(group, channel));
        }

        int totalCount() { return local.size() + world.size(); }

        void filter(String word) {
            visible.clear();
            boolean byNumber = word.matches("[0-9]+");
            for (int position = 0; position < totalCount(); position++) {
                boolean matches = byNumber ? word.equals(numbers.get(position)) : searchKeys.get(position).contains(word);
                if (matches) visible.add(position);
            }
            notifyDataSetChanged();
        }

        private String channelNumber(int position) {
            if (position >= local.size()) return Integer.toString(position + 1);
            LocalRow row = local.get(position);
            return groups == ChannelCatalog.GROUPS ? ChannelCatalog.displayNumber(row.group, row.channel)
                    : groups[row.group].channels[row.channel].number;
        }

        @Override public int getCount() { return visible.size(); }

        @Override public Object getItem(int position) {
            int source = visible.get(position);
            return source < local.size() ? local.get(source) : world.get(source - local.size());
        }

        @Override public long getItemId(int position) { return visible.get(position); }

        void play(int position) {
            position = visible.get(position);
            if (position < local.size()) {
                LocalRow row = local.get(position);
                host.play(row.group, row.channel);
            } else {
                host.playCountry(world.get(position - local.size()), world);
            }
        }

        int selectedPosition() {
            for (int i = 0; i < visible.size(); i++) if (playing(visible.get(i))) return i;
            return -1;
        }

        private boolean playing(int position) {
            if (position < local.size()) {
                LocalRow row = local.get(position);
                return playingStation == null && row.group == playingGroup && row.channel == playingChannel;
            }
            return playingStation != null && playingStation.id.equals(world.get(position - local.size()).id);
        }

        private void toggleFavorite(int position) {
            if (position < local.size()) {
                LocalRow row = local.get(position);
                host.toggleFavorite(row.group, row.channel);
            } else host.toggleCountryFavorite(world.get(position - local.size()));
        }

        @Override public View getView(int position, View recycled, ViewGroup parent) {
            position = visible.get(position);
            final int source = position;
            ChannelRow row = recycled instanceof ChannelRow
                    ? (ChannelRow) recycled : new ChannelRow(parent.getContext());
            if (position < local.size()) {
                LocalRow slot = local.get(position);
                Channel channel = groups[slot.group].channels[slot.channel];
                row.bind(numbers.get(position), channel.name, playing(position),
                        host.isFavorite(groups[slot.group], channel), () -> toggleFavorite(source));
            } else {
                WorldChannelCatalog.Station station = world.get(position - local.size());
                row.bind(numbers.get(position), station.name, playing(position),
                        host.isCountryFavorite(station), () -> toggleFavorite(source));
            }
            return row;
        }
    }

    private static final class ChannelRow extends LinearLayout {
        private final TextView number;
        private final TextView name;
        private final TextView current;
        private final TextView favorite;

        ChannelRow(Context context) {
            super(context);
            setGravity(Gravity.CENTER_VERTICAL);
            setMinimumHeight(dp(this, 54));
            setPadding(dp(this, 8), dp(this, 7), dp(this, 8), dp(this, 7));
            number = label(context, 13, MUTED);
            number.setGravity(Gravity.CENTER);
            addView(number, new LayoutParams(dp(this, 40), -2));
            name = label(context, 16, Color.WHITE);
            name.setMaxLines(2);
            name.setEllipsize(TextUtils.TruncateAt.END);
            addView(name, new LayoutParams(0, -2, 1));
            current = label(context, 12, ACCENT);
            current.setPadding(dp(this, 8), 0, 0, 0);
            current.setText(R.string.phone_selected);
            addView(current);
            favorite = label(context, 26, MUTED);
            favorite.setId(R.id.phone_channel_favorite);
            favorite.setGravity(Gravity.CENTER);
            favorite.setFocusable(false);
            addView(favorite, new LayoutParams(dp(this, 48), dp(this, 48)));
        }

        void bind(String channelNumber, String title, boolean playing, boolean saved, Runnable toggleFavorite) {
            number.setText(channelNumber);
            name.setText(title);
            name.setTextColor(playing ? ACCENT : Color.WHITE);
            current.setVisibility(playing ? VISIBLE : GONE);
            setBackgroundColor(playing ? TILE : Color.TRANSPARENT);
            favorite.setText(saved ? "★" : "☆");
            favorite.setTextColor(saved ? ACCENT : MUTED);
            favorite.setContentDescription(getContext().getText(saved
                    ? R.string.phone_remove_favorite : R.string.phone_add_favorite));
            favorite.setOnClickListener(view -> toggleFavorite.run());
        }
    }
}
