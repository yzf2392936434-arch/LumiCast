package xiao.bu.tv;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.FrameLayout;

/** Player root without the platform full-screen focus tint. */
public final class PlayerRootLayout extends FrameLayout {
    private android.view.View receiverVideo, receiverCursor;
    private android.view.View startupWallpaper;
    private PhonePlayerControls phoneControls;
    private boolean phoneOverlay;
    private int startupDrawIndex=-1;
    @Override protected void onFinishInflate(){
        super.onFinishInflate();startupWallpaper=findViewById(R.id.startup_background);
    }
    @Override protected void dispatchDraw(android.graphics.Canvas canvas){
        startupDrawIndex=startupWallpaper!=null&&startupWallpaper.getVisibility()==VISIBLE?indexOfChild(startupWallpaper):-1;
        try{super.dispatchDraw(canvas);}finally{startupDrawIndex=-1;}
    }
    @Override protected int getChildDrawingOrder(int count,int position){
        if(startupDrawIndex<0)return position;
        return position==count-1?startupDrawIndex:position>=startupDrawIndex?position+1:position;
    }
    void setReceiverLayers(android.view.View video, android.view.View cursor) {
        boolean modeChanged = (receiverVideo == null) != (video == null);
        receiverVideo=video; receiverCursor=cursor;
        if (modeChanged) requestLayout();
        invalidate();
    }

    void setPhoneControls(PhonePlayerControls controls) {
        phoneControls = controls;
        // The dock fills the reserved padding area below the video children.
        setClipToPadding(false);
        addView(controls, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
    }

    void setPhoneOverlay(boolean overlay) {
        if (phoneOverlay == overlay) return;
        phoneOverlay = overlay;
        requestLayout();
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int inset = 0;
        if (phoneControls != null && receiverVideo == null && !phoneOverlay) {
            phoneControls.measure(widthSpec, MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
            inset = phoneControls.getMeasuredHeight();
        }
        if (getPaddingBottom() != inset) setPadding(getPaddingLeft(), getPaddingTop(), getPaddingRight(), inset);
        super.onMeasure(widthSpec, heightSpec);
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        super.onLayout(changed, left, top, right, bottom);
        if (phoneControls != null && phoneControls.getVisibility() == VISIBLE && receiverVideo == null) {
            int height = getHeight();
            phoneControls.layout(getPaddingLeft(), height - phoneControls.getMeasuredHeight(),
                    getWidth() - getPaddingRight(), height);
        }
    }
    @Override protected boolean drawChild(android.graphics.Canvas canvas,
            android.view.View child, long drawingTime) {
        if(receiverVideo!=null && child!=receiverVideo && child!=receiverCursor)return true;
        return super.drawChild(canvas,child,drawingTime);
    }

    public PlayerRootLayout(Context context) {
        this(context, null);
    }

    public PlayerRootLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        setChildrenDrawingOrderEnabled(true);
        // The player root receives focus when menus close so remote keys keep
        // working. It is not a selectable control: Oreo's default focus highlight
        // would otherwise tint the entire playback area in mouse/remote mode.
        if (android.os.Build.VERSION.SDK_INT >= 26) {
            setDefaultFocusHighlightEnabled(false);
        }
    }

}
