package xiao.bu.tv;

import android.content.Context;

/** The independent edition keeps playback and crash diagnostics on the device. */
final class CrashReporting {
    private static final String TAG = "NtvLocalDiagnostics";
    private static volatile boolean started;

    private CrashReporting() { }

    static boolean enabled() { return started; }
    static void startIfAllowed(Context context) { started = !BuildConfig.DEBUG; }

    static void postPlayerError(Throwable error, Thread origin) {
        if (started) AppLog.w(TAG, "Playback error", error);
    }

    static void putDiagnostic(Context context, String key, String value) {
        if (started) AppLog.d(TAG, key + "=" + value);
    }
}
