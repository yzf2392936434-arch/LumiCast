package xiao.bu.tv;

import android.content.Context;
import android.util.JsonReader;
import android.util.JsonToken;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.text.Normalizer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;

/** Offline-first public channel directory. Opening it performs no stream health probes. */
final class WorldChannelCatalog {
    private static final String ARCHIVE = "world-channels.zip";
    private static final String API = "https://raw.githubusercontent.com/iptv-org/api/gh-pages/";
    private static final int SOURCE_LIMIT = 20 * 1024 * 1024;
    private static final int MAX_RESULTS = 120;
    private static final java.util.regex.Pattern SEARCH_SEPARATORS = java.util.regex.Pattern.compile("[\\p{M}\\p{P}\\p{Z}\\s]+");
    private static Index current;

    static final class Line {
        final String title, url;
        final boolean regional;

        Line(String title, String url, boolean regional) {
            this.title = title;
            this.url = url;
            this.regional = regional;
        }
    }

    static final class Station {
        final String id, name, country;
        final List<Line> lines;
        final List<String> alternateNames;
        private final String primary;
        private final String aliases;

        Station(String id, String name, String country, List<String> altNames, List<Line> lines) {
            this.id = id;
            this.name = name;
            this.country = country;
            this.lines = Collections.unmodifiableList(lines);
            alternateNames = Collections.unmodifiableList(altNames);
            primary = key(name);
            StringBuilder combined = new StringBuilder(name);
            for (String alias : altNames) combined.append(' ').append(alias);
            for (Line line : lines) combined.append(' ').append(line.title);
            aliases = key(combined.toString());
        }

        String searchKey() { return aliases; }
    }

    static final class Index {
        final List<Station> stations;
        final List<String> countries;

        Index(List<Station> stations) {
            Collections.sort(stations, (a, b) -> a.name.compareToIgnoreCase(b.name));
            this.stations = Collections.unmodifiableList(stations);
            TreeSet<String> codes = new TreeSet<>(countryCodes());
            for (Station station : stations) if (!station.country.isEmpty()) codes.add(station.country);
            countries = Collections.unmodifiableList(new ArrayList<>(codes));
        }

        List<Station> forCountry(String code) {
            ArrayList<Station> result = new ArrayList<>();
            for (Station station : stations) if (code.equals(station.country)) result.add(station);
            return result;
        }

        List<Station> search(String query, String country, Locale locale) {
            String word = key(query);
            ArrayList<Station> best = new ArrayList<>(), also = new ArrayList<>();
            Map<String, String> regionKeys = new HashMap<>();
            for (Station station : stations) {
                if (!country.isEmpty() && !country.equals(station.country)) continue;
                if ((word.isEmpty() || station.primary.startsWith(word)) && best.size() < MAX_RESULTS) {
                    best.add(station);
                } else if (also.size() < MAX_RESULTS) {
                    String region = regionKeys.get(station.country);
                    if (region == null) {
                        region = key(countryName(station.country, locale) + " " + countryName(station.country, Locale.ENGLISH)
                                + " " + countryName(station.country, Locale.SIMPLIFIED_CHINESE) + " " + station.country);
                        regionKeys.put(station.country, region);
                    }
                    if (station.aliases.contains(word) || region.contains(word)) also.add(station);
                }
                if (best.size() == MAX_RESULTS) break;
            }
            best.addAll(also.subList(0, Math.min(also.size(), MAX_RESULTS - best.size())));
            return best;
        }
    }

    private WorldChannelCatalog() { }

    static List<String> countryCodes() {
        TreeSet<String> codes = new TreeSet<>();
        Collections.addAll(codes, Locale.getISOCountries());
        codes.add("XK");
        return new ArrayList<>(codes);
    }

    static synchronized Index load(Context context) throws IOException {
        if (current != null) return current;
        File cache = new File(context.getCacheDir(), ARCHIVE);
        if (cache.isFile()) {
            try (InputStream input = new FileInputStream(cache)) { current = read(input); }
            catch (IOException | RuntimeException invalid) { AppLog.w("WorldCatalog", "Using bundled directory", invalid); }
        }
        if (current == null) {
            try (InputStream input = context.getAssets().open(ARCHIVE)) { current = read(input); }
        }
        return current;
    }

    static synchronized Index refresh(Context context) throws IOException {
        File staged = File.createTempFile("world-channels-", ".zip", context.getCacheDir());
        try {
            try (ZipOutputStream output = new ZipOutputStream(new FileOutputStream(staged))) {
                for (String file : new String[]{"streams.json", "channels.json"}) {
                    output.putNextEntry(new ZipEntry(file));
                    fetch(API + file, output, SOURCE_LIMIT);
                    output.closeEntry();
                }
            }
            Index next;
            try (InputStream input = new FileInputStream(staged)) { next = read(input); }
            if (!staged.renameTo(new File(context.getCacheDir(), ARCHIVE))) throw new IOException("Could not publish directory");
            current = next;
            return next;
        } finally { staged.delete(); }
    }

    static void fetch(String address, OutputStream output, int sizeLimit) throws IOException {
        HttpURLConnection connection = NetworkClient.openBounded(new URL(address), 10_000);
        connection.setConnectTimeout(6500);
        connection.setReadTimeout(8000);
        connection.setRequestProperty("Accept", "application/json");
        try {
            if (connection.getResponseCode() != 200) throw new IOException("Directory HTTP " + connection.getResponseCode());
            try (InputStream input = connection.getInputStream()) {
                byte[] bytes = new byte[16384];
                int count, total = 0;
                while ((count = input.read(bytes)) != -1) {
                    total += count;
                    if (total > sizeLimit) throw new IOException("Directory response too large");
                    output.write(bytes, 0, count);
                }
            }
        } finally { connection.disconnect(); }
    }

    static Index read(InputStream input) throws IOException {
        try (ZipInputStream packed = new ZipInputStream(input)) {
            ZipEntry streams = packed.getNextEntry();
            if (streams == null || !"streams.json".equals(streams.getName())) throw new IOException("Missing streams");
            Map<String, List<Line>> lines = readStreams(new JsonReader(new InputStreamReader(packed, "UTF-8")));
            packed.closeEntry();
            ZipEntry channels = packed.getNextEntry();
            if (channels == null || !"channels.json".equals(channels.getName())) throw new IOException("Missing channels");
            List<Station> stations = readStations(new JsonReader(new InputStreamReader(packed, "UTF-8")), lines);
            if (stations.isEmpty()) throw new IOException("Public directory is empty");
            return new Index(stations);
        }
    }

    private static Map<String, List<Line>> readStreams(JsonReader reader) throws IOException {
        Map<String, List<Line>> index = new HashMap<>();
        reader.beginArray();
        while (reader.hasNext()) {
            String channel = "", title = "", url = "";
            boolean regional = false;
            reader.beginObject();
            while (reader.hasNext()) {
                String field = reader.nextName();
                switch (field) {
                    case "channel": channel = readString(reader); break;
                    case "title": title = readString(reader); break;
                    case "url": url = readString(reader); break;
                    case "labels": regional = readStrings(reader).contains("Geo-blocked"); break;
                    default: reader.skipValue();
                }
            }
            reader.endObject();
            if (channel.isEmpty() || !publicAddress(url)) continue;
            List<Line> choices = index.get(channel);
            if (choices == null) { choices = new ArrayList<>(); index.put(channel, choices); }
            boolean duplicate = false;
            for (Line line : choices) if (line.url.equals(url)) { duplicate = true; break; }
            if (!duplicate) choices.add(new Line(title, url, regional));
        }
        reader.endArray();
        Comparator<Line> preference = (a, b) -> {
            if (a.regional != b.regional) return a.regional ? 1 : -1;
            boolean secureA = a.url.startsWith("https://"), secureB = b.url.startsWith("https://");
            return secureA == secureB ? 0 : secureA ? -1 : 1;
        };
        for (List<Line> choices : index.values()) Collections.sort(choices, preference);
        return index;
    }

    private static List<Station> readStations(JsonReader reader, Map<String, List<Line>> lines) throws IOException {
        List<Station> stations = new ArrayList<>();
        reader.beginArray();
        while (reader.hasNext()) {
            String id = "", name = "", country = "";
            List<String> alt = Collections.emptyList();
            boolean adult = false;
            reader.beginObject();
            while (reader.hasNext()) {
                switch (reader.nextName()) {
                    case "id": id = readString(reader); break;
                    case "name": name = readString(reader); break;
                    case "country":
                        country = readString(reader);
                        if ("UK".equals(country)) country = "GB";
                        break;
                    case "alt_names": alt = readStrings(reader); break;
                    case "is_nsfw": if (reader.peek() == JsonToken.BOOLEAN) adult = reader.nextBoolean(); else reader.skipValue(); break;
                    default: reader.skipValue();
                }
            }
            reader.endObject();
            List<Line> available = lines.remove(id);
            if (!adult && !name.isEmpty() && available != null) stations.add(new Station(id, name, country, alt, available));
        }
        reader.endArray();
        return stations;
    }

    private static String readString(JsonReader reader) throws IOException {
        if (reader.peek() == JsonToken.STRING) return reader.nextString();
        reader.skipValue();
        return "";
    }

    private static List<String> readStrings(JsonReader reader) throws IOException {
        List<String> strings = new ArrayList<>();
        if (reader.peek() != JsonToken.BEGIN_ARRAY) { reader.skipValue(); return strings; }
        reader.beginArray();
        while (reader.hasNext()) { String value = readString(reader); if (!value.isEmpty()) strings.add(value); }
        reader.endArray();
        return strings;
    }

    static String countryName(String country, Locale locale) {
        if (country.isEmpty()) return "";
        String label = new Locale("", country).getDisplayCountry(locale);
        return label.isEmpty() ? country : label;
    }

    static String countrySearchText(String country) {
        StringBuilder names = new StringBuilder(country);
        for (Locale language : new Locale[]{Locale.SIMPLIFIED_CHINESE, Locale.TRADITIONAL_CHINESE,
                Locale.ENGLISH, Locale.JAPANESE, Locale.KOREAN})
            names.append(' ').append(countryName(country, language));
        if ("GB".equals(country)) names.append(" UK");
        if ("US".equals(country)) names.append(" USA");
        if ("KR".equals(country)) names.append(" 한국");
        return names.toString();
    }

    static String key(String value) {
        if (value == null) return "";
        return SEARCH_SEPARATORS.matcher(Normalizer.normalize(value, Normalizer.Form.NFKD).toLowerCase(Locale.ROOT)).replaceAll("");
    }

    private static boolean publicAddress(String address) {
        try {
            URI uri = new URI(address);
            String host = uri.getHost();
            if (host == null || uri.getUserInfo() != null || address.length() > 8192
                    || !("http".equalsIgnoreCase(uri.getScheme()) || "https".equalsIgnoreCase(uri.getScheme()))) return false;
            host = host.toLowerCase(Locale.ROOT);
            return host.contains(".") && !host.endsWith(".local") && !host.endsWith(".localhost")
                    && !host.matches("(?:0|10|127|169\\.254|192\\.168|172\\.(?:1[6-9]|2[0-9]|3[01]))(?:\\.\\d+)+");
        } catch (Exception malformed) { return false; }
    }
}
