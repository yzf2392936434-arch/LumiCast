package xiao.bu.tv;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** The app's display language is independent of channel data and protocol formatting. */
public final class UiLanguage {
    private static final String SETTINGS = "display_language";
    private static final String SELECTION = "selection";
    private static final String[] MODES = {"system", "zh-CN", "zh-TW", "ja", "ko", "en"};
    private static final Locale[] LOCALES = {
            null, Locale.SIMPLIFIED_CHINESE, Locale.TRADITIONAL_CHINESE,
            Locale.JAPANESE, Locale.KOREAN, Locale.ENGLISH
    };
    private static final Pattern LINE_NUMBER = Pattern.compile("线路(?=\\s*\\d)");
    private static final String[] STATUS_PREFIXES = {
            "缓冲中", "正在缓冲", "播放失败：", "连接失败：", "连接失败: ",
            "网页加载失败: ", "启动失败: ", "等待播放：", "播放错误: "
    };
    private static final JSONObject EMPTY = new JSONObject();
    private static volatile JSONObject messages = EMPTY;
    private static volatile String language = "zh-CN";

    private UiLanguage() { }

    static Context wrap(Context base) {
        Locale selected = LOCALES[selection(base)];
        if (selected == null) selected = deviceLocale();
        Context context = base;
        if (Build.VERSION.SDK_INT >= 17) {
            if (selected != null) {
                Configuration override = new Configuration();
                override.setLocale(selected);
                context = base.createConfigurationContext(override);
            }
        } else {
            applyLegacyLocale(base, selected);
        }
        loadMessages(context);
        return context;
    }

    @SuppressWarnings("deprecation")
    private static Locale deviceLocale() {
        Configuration config = Resources.getSystem().getConfiguration();
        Locale locale = Build.VERSION.SDK_INT >= 24 ? config.getLocales().get(0) : config.locale;
        if (locale == null || !"zh".equals(locale.getLanguage())) return locale;
        String country = locale.getCountry();
        boolean traditional = "TW".equals(country) || "HK".equals(country) || "MO".equals(country);
        if (Build.VERSION.SDK_INT >= 21 && !locale.getScript().isEmpty())
            traditional = "Hant".equals(locale.getScript());
        return traditional ? Locale.TRADITIONAL_CHINESE : Locale.SIMPLIFIED_CHINESE;
    }

    @SuppressWarnings("deprecation")
    private static void applyLegacyLocale(Context base, Locale selected) {
        Resources resources = base.getResources();
        Configuration config = new Configuration(resources.getConfiguration());
        Locale target = selected == null ? Resources.getSystem().getConfiguration().locale : selected;
        if (target != null && !target.equals(config.locale)) {
            config.locale = target;
            resources.updateConfiguration(config, resources.getDisplayMetrics());
        }
    }

    private static synchronized void loadMessages(Context context) {
        String wanted = context.getString(R.string.ui_locale_code);
        if (wanted.equals(language)) return;
        JSONObject next = EMPTY;
        if (!"zh-CN".equals(wanted)) {
            InputStream input = null;
            try {
                input = context.getAssets().open("control/locales.json");
                ByteArrayOutputStream bytes = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];
                int count;
                while ((count = input.read(buffer)) != -1) bytes.write(buffer, 0, count);
                JSONObject catalogue = new JSONObject(bytes.toString("UTF-8")).optJSONObject(wanted);
                if (catalogue != null) next = catalogue;
            } catch (IOException | org.json.JSONException error) {
                AppLog.w("UiLanguage", "Could not load display translations", error);
            } finally {
                if (input != null) try { input.close(); } catch (IOException ignored) { }
            }
        }
        messages = next;
        language = wanted;
    }

    private static SharedPreferences preferences(Context context) {
        return context.getSharedPreferences(SETTINGS, Context.MODE_PRIVATE);
    }

    static int selection(Context context) {
        String stored = preferences(context).getString(SELECTION, MODES[0]);
        for (int index = 0; index < MODES.length; index++) {
            if (MODES[index].equals(stored)) return index;
        }
        return 0;
    }

    static boolean select(Context context, int index) {
        if (index < 0 || index >= MODES.length || selection(context) == index) return false;
        preferences(context).edit().putString(SELECTION, MODES[index]).apply();
        return true;
    }

    static String effective() { return language; }

    public static String text(String source) {
        return source == null ? "" : messages.optString(source, source);
    }

    static String[] labels(String[] source) {
        String[] labels = new String[source.length];
        for (int index = 0; index < source.length; index++) {
            String label = source[index];
            if (label != null && (label.endsWith(" ●") || label.endsWith(" ○"))) {
                int end = label.length() - 2;
                labels[index] = text(label.substring(0, end)) + label.substring(end);
            } else {
                labels[index] = text(label);
            }
        }
        return labels;
    }

    static String playbackStatus(String source) {
        if (source == null || messages == EMPTY) return source == null ? "" : source;
        String direct = text(source);
        if (!source.equals(direct)) return direct;
        String[] segments = source.split(" · ", -1);
        StringBuilder result = new StringBuilder(source.length());
        for (int index = 0; index < segments.length; index++) {
            if (index > 0) result.append(" · ");
            String segment = segments[index];
            String localized = text(segment);
            if (localized.equals(segment)) {
                localized = LINE_NUMBER.matcher(segment).replaceAll(Matcher.quoteReplacement(text("线路")));
                for (String prefix : STATUS_PREFIXES) {
                    if (localized.startsWith(prefix)) {
                        localized = text(prefix) + localized.substring(prefix.length());
                        break;
                    }
                }
            }
            result.append(localized);
        }
        return result.toString();
    }
}
