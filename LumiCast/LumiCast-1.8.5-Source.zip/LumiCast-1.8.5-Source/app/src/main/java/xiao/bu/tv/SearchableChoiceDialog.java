package xiao.bu.tv;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import static xiao.bu.tv.PhonePlayerControls.ACCENT;
import static xiao.bu.tv.PhonePlayerControls.LINE;
import static xiao.bu.tv.PhonePlayerControls.MUTED;
import static xiao.bu.tv.PhonePlayerControls.PANEL;
import static xiao.bu.tv.PhonePlayerControls.TILE;
import static xiao.bu.tv.PhonePlayerControls.dp;
import static xiao.bu.tv.PhonePlayerControls.label;
import static xiao.bu.tv.PhonePlayerControls.rounded;

/** A fixed search field above a filtered list, retaining each choice's original index. */
@SuppressWarnings("deprecation")
final class SearchableChoiceDialog extends Dialog {
    static final class Choice {
        final int index;
        final String label, searchKey;

        Choice(int index, String label, String searchableText) {
            this.index = index;
            this.label = label;
            searchKey = WorldChannelCatalog.key(searchableText);
        }
    }

    interface Listener {
        void select(int index);
    }

    private CharSequence heading;
    private List<Choice> choices;
    private int selected;
    private Listener listener;
    private final ArrayList<Choice> visible = new ArrayList<>();
    private final Rows rows = new Rows();
    private LinearLayout content;
    private TextView title, empty, clear;
    private EditText query;
    private ListView list;

    SearchableChoiceDialog(Context context, CharSequence heading, List<Choice> choices,
            int selected, Listener listener) {
        super(context);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        updateChoices(heading, choices, selected, listener);
    }

    void updateChoices(CharSequence heading, List<Choice> choices, int selected, Listener listener) {
        this.heading = heading;
        this.choices = choices;
        this.selected = selected;
        this.listener = listener;
        if (title == null) return;
        title.setText(heading);
        filter();
    }

    @Override protected void onCreate(Bundle savedState) {
        super.onCreate(savedState);
        Context context = getContext();
        content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(content, 16), dp(content, 12), dp(content, 16), dp(content, 8));
        content.setBackgroundDrawable(rounded(context, PANEL, 20));
        content.setFocusableInTouchMode(true);

        title = label(context, 21, Color.WHITE);
        title.setText(heading);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setPadding(0, dp(content, 6), 0, dp(content, 14));
        content.addView(title, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout input = new LinearLayout(context);
        input.setGravity(Gravity.CENTER_VERTICAL);
        input.setBackgroundDrawable(rounded(context, TILE, 12));
        query = new EditText(context);
        query.setId(R.id.phone_country_search);
        query.setHint(R.string.phone_country_search);
        query.setTextColor(Color.WHITE);
        query.setHintTextColor(MUTED);
        query.setTextSize(16);
        query.setSingleLine(true);
        query.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});
        query.setInputType(InputType.TYPE_CLASS_TEXT);
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        query.setPadding(dp(content, 12), 0, dp(content, 4), 0);
        query.setBackgroundColor(Color.TRANSPARENT);
        query.setOnEditorActionListener((view, action, event) -> {
            if (action != EditorInfo.IME_ACTION_SEARCH) return false;
            hideKeyboard();
            return true;
        });
        input.addView(query, new LinearLayout.LayoutParams(0, dp(content, 50), 1));
        clear = label(context, 26, ACCENT);
        clear.setId(R.id.phone_country_clear);
        clear.setText("×");
        clear.setFocusable(true);
        clear.setGravity(Gravity.CENTER);
        clear.setContentDescription(context.getText(R.string.phone_clear_search));
        clear.setOnClickListener(view -> query.setText(""));
        input.addView(clear, new LinearLayout.LayoutParams(dp(content, 48), dp(content, 50)));
        content.addView(input, new LinearLayout.LayoutParams(-1, -2));

        list = new ListView(context);
        list.setId(R.id.phone_country_list);
        list.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        list.setDivider(new ColorDrawable(LINE));
        list.setDividerHeight(dp(content, 1));
        list.setAdapter(rows);
        list.setOnItemClickListener((parent, view, position, id) -> {
            int originalIndex = visible.get(position).index;
            dismiss();
            listener.select(originalIndex);
        });
        LinearLayout.LayoutParams resultsLayout = new LinearLayout.LayoutParams(-1, 0, 1);
        resultsLayout.topMargin = dp(content, 8);
        content.addView(list, resultsLayout);

        empty = label(context, 16, MUTED);
        empty.setId(R.id.phone_country_empty);
        empty.setText(R.string.phone_world_empty);
        empty.setGravity(Gravity.CENTER);
        content.addView(empty, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView cancel = label(context, 16, ACCENT);
        cancel.setText(R.string.cancel);
        cancel.setFocusable(true);
        cancel.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        cancel.setPadding(dp(content, 12), 0, dp(content, 12), 0);
        cancel.setMinimumHeight(dp(content, 48));
        cancel.setOnClickListener(view -> dismiss());
        content.addView(cancel, new LinearLayout.LayoutParams(-1, -2));
        setContentView(content);
        query.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence text, int start, int count, int after) { }
            public void onTextChanged(CharSequence text, int start, int before, int count) { filter(); }
            public void afterTextChanged(Editable text) { }
        });
        content.requestFocus();
        filter();
    }

    @Override protected void onStart() {
        super.onStart();
        updateWindowSize();
    }

    void updateWindowSize() {
        Window window = getWindow();
        if (window == null || content == null) return;
        android.util.DisplayMetrics screen = getContext().getResources().getDisplayMetrics();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        window.setLayout(Math.min(screen.widthPixels - dp(content, 24), dp(content, 550)),
                Math.min(screen.heightPixels - dp(content, 32), dp(content, 620)));
    }

    private void filter() {
        String word = WorldChannelCatalog.key(query.getText().toString());
        visible.clear();
        for (Choice choice : choices)
            if (word.isEmpty() || choice.searchKey.contains(word)) visible.add(choice);
        clear.setVisibility(query.length() == 0 ? View.INVISIBLE : View.VISIBLE);
        list.clearChoices();
        rows.notifyDataSetChanged();
        int checked = -1;
        for (int position = 0; position < visible.size(); position++) {
            if (visible.get(position).index == selected) checked = position;
        }
        if (checked >= 0) list.setItemChecked(checked, true);
        list.setSelection(word.isEmpty() ? Math.max(0, checked) : 0);
        list.setVisibility(visible.isEmpty() ? View.GONE : View.VISIBLE);
        empty.setVisibility(visible.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void hideKeyboard() {
        InputMethodManager keyboard = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (keyboard != null && query != null) keyboard.hideSoftInputFromWindow(query.getWindowToken(), 0);
    }

    @Override public void dismiss() {
        hideKeyboard();
        super.dismiss();
    }

    private final class Rows extends BaseAdapter {
        @Override public int getCount() { return visible.size(); }
        @Override public Object getItem(int position) { return visible.get(position); }
        @Override public long getItemId(int position) { return visible.get(position).index; }

        @Override public View getView(int position, View recycled, ViewGroup parent) {
            CheckedTextView text = (CheckedTextView) recycled;
            if (text == null) {
                text = new CheckedTextView(getContext());
                text.setTextSize(18);
                text.setGravity(Gravity.CENTER_VERTICAL);
                text.setPadding(dp(content, 12), dp(content, 10), dp(content, 12), dp(content, 10));
                text.setMinHeight(dp(content, 52));
                text.setCheckMarkDrawable(android.R.drawable.btn_radio);
            }
            Choice choice = visible.get(position);
            text.setText(choice.label);
            text.setTextColor(choice.index == selected ? ACCENT : Color.WHITE);
            text.setChecked(choice.index == selected);
            return text;
        }
    }
}
