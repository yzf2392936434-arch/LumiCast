package xiao.bu.tv;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

/** Stores the station metadata needed to play a worldwide favorite after restart. */
final class WorldChannelFavorites {
    private final LinkedHashMap<String, WorldChannelCatalog.Station> stations = new LinkedHashMap<>();

    static String key(WorldChannelCatalog.Station station) { return "world:" + station.id; }

    void put(WorldChannelCatalog.Station station) { stations.put(key(station), station); }

    void remove(String key) { stations.remove(key); }

    WorldChannelCatalog.Station get(String key) { return stations.get(key); }

    Channel channel(String key) {
        WorldChannelCatalog.Station station = stations.get(key);
        if (station == null) return null;
        String[] urls = new String[station.lines.size()];
        for (int index = 0; index < urls.length; index++) urls[index] = station.lines.get(index).url;
        return new Channel("", station.name, "quick", urls, null, null, null, station.id)
                .asFavorite(key, ChannelCatalog.SOURCE_CUSTOM);
    }

    void restore(String saved) {
        stations.clear();
        try {
            JSONArray entries = new JSONArray(saved);
            for (int index = 0; index < entries.length(); index++) {
                JSONObject entry = entries.optJSONObject(index);
                if (entry == null) continue;
                String id = entry.optString("id", ""), name = entry.optString("name", "");
                JSONArray sources = entry.optJSONArray("lines");
                if (id.isEmpty() || name.isEmpty() || sources == null) continue;
                ArrayList<WorldChannelCatalog.Line> lines = new ArrayList<>();
                for (int lineIndex = 0; lineIndex < sources.length(); lineIndex++) {
                    JSONObject line = sources.optJSONObject(lineIndex);
                    if (line == null) continue;
                    String url = line.optString("url", "");
                    if (!url.isEmpty()) lines.add(new WorldChannelCatalog.Line(
                            line.optString("title", ""), url, line.optBoolean("regional", false)));
                }
                if (lines.isEmpty()) continue;
                put(new WorldChannelCatalog.Station(id, name, entry.optString("country", ""),
                        new ArrayList<>(), lines));
            }
        } catch (JSONException invalid) {
            AppLog.w("WorldFavorites", "Could not read saved worldwide favorites", invalid);
        }
    }

    String serialize() {
        JSONArray entries = new JSONArray();
        try {
            for (Map.Entry<String, WorldChannelCatalog.Station> item : stations.entrySet()) {
                WorldChannelCatalog.Station station = item.getValue();
                JSONArray lines = new JSONArray();
                for (WorldChannelCatalog.Line line : station.lines) {
                    lines.put(new JSONObject().put("title", line.title).put("url", line.url)
                            .put("regional", line.regional));
                }
                entries.put(new JSONObject().put("id", station.id).put("name", station.name)
                        .put("country", station.country).put("lines", lines));
            }
        } catch (JSONException invalid) {
            throw new IllegalStateException("Could not serialize worldwide favorites", invalid);
        }
        return entries.toString();
    }
}
