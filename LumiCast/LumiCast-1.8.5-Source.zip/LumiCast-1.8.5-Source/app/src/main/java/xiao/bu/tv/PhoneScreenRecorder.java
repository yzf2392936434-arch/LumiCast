package xiao.bu.tv;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Rect;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.lang.ref.WeakReference;

/** A single user-authorized screen capture, saved as a video in the gallery. */
@TargetApi(21)
@SuppressWarnings("deprecation")
public final class PhoneScreenRecorder extends Service {
    private static final String CHANNEL = "screen_recording";
    private static final String STOP = "xiao.bu.tv.STOP_SCREEN_RECORDING";
    private static final int NOTIFICATION_ID = 701;
    private static State state = State.IDLE;
    private static WeakReference<Runnable> observer = new WeakReference<>(null);

    private enum State { IDLE, STARTING, RECORDING, FINISHING }

    private final Handler main = new Handler(Looper.getMainLooper());
    private final MediaProjection.Callback projectionCallback = new MediaProjection.Callback() {
        @Override public void onStop() { finishCapture(true); }
    };
    private MediaProjection projection;
    private VirtualDisplay display;
    private MediaRecorder recorder;
    private ParcelFileDescriptor descriptor;
    private Uri mediaUri;
    private File pendingFile;
    private File finalFile;

    static boolean recording() { return state == State.RECORDING; }
    static boolean busy() { return state == State.STARTING || state == State.FINISHING; }

    static void observe(Runnable listener) {
        observer = new WeakReference<>(listener);
        listener.run();
    }

    static void unobserve(Runnable listener) {
        if (observer.get() == listener) observer.clear();
    }

    private static void setState(State next) {
        state = next;
        Runnable listener = observer.get();
        if (listener != null) listener.run();
    }

    static void begin(Activity activity, Intent consent) {
        if (state != State.IDLE) return;
        DisplayMetrics metrics = new DisplayMetrics();
        activity.getWindowManager().getDefaultDisplay().getRealMetrics(metrics);
        if (Build.VERSION.SDK_INT >= 30) {
            Rect bounds = activity.getWindowManager().getMaximumWindowMetrics().getBounds();
            metrics.widthPixels = bounds.width();
            metrics.heightPixels = bounds.height();
        }
        Intent request = new Intent(activity, PhoneScreenRecorder.class)
                .putExtra("consent", consent).putExtra("width", metrics.widthPixels)
                .putExtra("height", metrics.heightPixels).putExtra("density", metrics.densityDpi);
        setState(State.STARTING);
        try {
            if (Build.VERSION.SDK_INT >= 26) activity.startForegroundService(request);
            else activity.startService(request);
        } catch (RuntimeException error) {
            AppLog.w("PhoneScreenRecorder", "Could not start capture service", error);
            setState(State.IDLE);
            Toast.makeText(activity, R.string.phone_record_failed, Toast.LENGTH_SHORT).show();
        }
    }

    static void stop(Context context) {
        context.startService(new Intent(context, PhoneScreenRecorder.class).setAction(STOP));
    }

    @Override protected void attachBaseContext(Context base) {
        super.attachBaseContext(UiLanguage.wrap(base));
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) {
            finishCapture(true);
            return START_NOT_STICKY;
        }
        if (state != State.STARTING) {
            if (state == State.IDLE) stopSelf();
            return START_NOT_STICKY;
        }
        try {
            Notification notification = captureNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIFICATION_ID, notification);
            }
            if (intent == null) throw new IOException("Missing capture request");
            prepareCapture(intent);
            setState(State.RECORDING);
        } catch (IOException | RuntimeException error) {
            AppLog.w("PhoneScreenRecorder", "Could not begin capture", error);
            finishCapture(false);
        }
        return START_NOT_STICKY;
    }

    private Notification captureNotification() {
        Notification.Builder builder;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            manager.createNotificationChannel(new NotificationChannel(CHANNEL,
                    getText(R.string.phone_record).toString(), NotificationManager.IMPORTANCE_LOW));
            builder = new Notification.Builder(this, CHANNEL);
        } else {
            builder = new Notification.Builder(this);
        }
        int pendingFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) pendingFlags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent end = PendingIntent.getService(this, 0,
                new Intent(this, PhoneScreenRecorder.class).setAction(STOP), pendingFlags);
        return builder.setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle(getText(R.string.phone_record_active)).setOngoing(true)
                .setUsesChronometer(true).setShowWhen(true)
                .setVisibility(Notification.VISIBILITY_PRIVATE)
                .addAction(android.R.drawable.ic_menu_close_clear_cancel, getText(R.string.phone_record_stop), end)
                .build();
    }

    private void prepareCapture(Intent request) throws IOException {
        Intent consent = request.getParcelableExtra("consent");
        if (consent == null) throw new IOException("Missing screen capture permission");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(Activity.RESULT_OK, consent);
        if (projection == null) throw new IOException("No screen capture session");
        projection.registerCallback(projectionCallback, main);

        int width = request.getIntExtra("width", 720);
        int height = request.getIntExtra("height", 1280);
        int density = request.getIntExtra("density", 160);
        float factor = Math.min(1f, 1280f / Math.max(1, Math.max(width, height)));
        width = Math.max(2, Math.round(width * factor / 2f) * 2);
        height = Math.max(2, Math.round(height * factor / 2f) * 2);
        recorder = new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width, height);
        recorder.setVideoFrameRate(24);
        recorder.setVideoEncodingBitRate(4_000_000);
        recorder.setMaxFileSize(2_000_000_000L);
        recorder.setOnInfoListener((source, what, extra) -> {
            if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) finishCapture(true);
        });
        recorder.setOnErrorListener((source, what, extra) -> finishCapture(false));
        prepareOutput();
        recorder.prepare();
        display = projection.createVirtualDisplay("Multilang TV", width, height,
                Math.max(1, Math.round(density * factor)), DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                recorder.getSurface(), null, main);
        if (display == null) throw new IOException("No virtual display");
        recorder.start();
    }

    private void prepareOutput() throws IOException {
        String name = "nTv-" + System.currentTimeMillis() + ".mp4";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentValues values = new ContentValues();
            values.put(MediaStore.Video.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
            values.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/nTv");
            values.put(MediaStore.Video.Media.IS_PENDING, 1);
            mediaUri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
            if (mediaUri == null) throw new IOException("Could not create gallery video");
            descriptor = getContentResolver().openFileDescriptor(mediaUri, "rw");
            if (descriptor == null) throw new IOException("Could not open gallery video");
            recorder.setOutputFile(descriptor.getFileDescriptor());
        } else {
            File directory = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "nTv");
            if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Could not open Movies folder");
            finalFile = new File(directory, name);
            pendingFile = File.createTempFile(".recording-", ".part", directory);
            recorder.setOutputFile(pendingFile.getAbsolutePath());
        }
    }

    private void finishCapture(boolean save) {
        if (state == State.IDLE || state == State.FINISHING) return;
        save = save && state == State.RECORDING;
        setState(State.FINISHING);
        if (save) {
            try { recorder.stop(); }
            catch (RuntimeException error) {
                AppLog.w("PhoneScreenRecorder", "Could not finalize capture", error);
                save = false;
            }
        }
        releaseCapture();
        boolean saved = finishOutput(save);
        stopForeground(true);
        setState(State.IDLE);
        Toast.makeText(this, saved ? R.string.phone_record_saved : R.string.phone_record_failed,
                Toast.LENGTH_SHORT).show();
        stopSelf();
    }

    private void releaseCapture() {
        if (display != null) { display.release(); display = null; }
        if (recorder != null) { recorder.release(); recorder = null; }
        if (projection != null) {
            projection.unregisterCallback(projectionCallback);
            projection.stop();
            projection = null;
        }
        if (descriptor != null) {
            try { descriptor.close(); } catch (IOException error) {
                AppLog.w("PhoneScreenRecorder", "Could not close recording output", error);
            }
            descriptor = null;
        }
    }

    private boolean finishOutput(boolean save) {
        try {
            if (mediaUri != null && save) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Video.Media.IS_PENDING, 0);
                if (getContentResolver().update(mediaUri, values, null, null) > 0) {
                    mediaUri = null;
                    return true;
                }
            }
            if (pendingFile != null && save && pendingFile.renameTo(finalFile)) {
                pendingFile = null;
                MediaScannerConnection.scanFile(this, new String[]{finalFile.getAbsolutePath()},
                        new String[]{"video/mp4"}, null);
                return true;
            }
        } catch (RuntimeException error) {
            AppLog.w("PhoneScreenRecorder", "Could not publish gallery video", error);
        } finally {
            if (mediaUri != null) {
                try { getContentResolver().delete(mediaUri, null, null); }
                catch (RuntimeException error) {
                    AppLog.w("PhoneScreenRecorder", "Could not remove pending gallery video", error);
                }
                mediaUri = null;
            }
            if (pendingFile != null) { pendingFile.delete(); pendingFile = null; }
            finalFile = null;
        }
        return false;
    }

    @Override public void onDestroy() {
        finishCapture(true);
        super.onDestroy();
    }
}
