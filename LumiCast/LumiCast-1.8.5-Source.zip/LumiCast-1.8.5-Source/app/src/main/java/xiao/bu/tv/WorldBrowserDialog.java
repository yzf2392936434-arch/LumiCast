package xiao.bu.tv;

import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.net.URLEncoder;
import java.text.Collator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

import static xiao.bu.tv.PhonePlayerControls.ACCENT;
import static xiao.bu.tv.PhonePlayerControls.LINE;
import static xiao.bu.tv.PhonePlayerControls.MUTED;
import static xiao.bu.tv.PhonePlayerControls.PANEL;
import static xiao.bu.tv.PhonePlayerControls.TILE;
import static xiao.bu.tv.PhonePlayerControls.dp;
import static xiao.bu.tv.PhonePlayerControls.label;
import static xiao.bu.tv.PhonePlayerControls.rounded;

/** Search the public channel directory and look up programmes by name. */
final class WorldBrowserDialog extends Dialog {
    interface Host {
        void play(WorldChannelCatalog.Station station, WorldChannelCatalog.Line line);
        List<Result> programs(String query);
    }

    static final class Result {
        final String name, detail;
        final Runnable open;

        Result(String name, String detail, Runnable open) {
            this.name = name;
            this.detail = detail;
            this.open = open;
        }
    }

    private final Host host;
    private final Locale locale;
    private final Rows adapter = new Rows();
    private LinearLayout content, filters;
    private TextView channelTab, programTab, status, countryButton, refresh, credit;
    private EditText query;
    private WorldChannelCatalog.Index catalog;
    private boolean programs, loadingCatalog;
    private int programRequest;
    private String country = "";
    private SearchableChoiceDialog countryDialog;

    WorldBrowserDialog(Context context, Host host) {
        super(context);
        this.host = host;
        locale = context.getResources().getConfiguration().locale;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
    }

    @Override protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        Context context = getContext();
        content = new LinearLayout(context);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(content, 16), dp(content, 8), dp(content, 16), dp(content, 9));
        content.setBackgroundDrawable(rounded(context, PANEL, 18));
        content.setFocusableInTouchMode(true);

        LinearLayout heading = new LinearLayout(context);
        heading.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = label(context, 21, Color.WHITE);
        title.setText(R.string.phone_world);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
        heading.addView(action(R.id.phone_world_close, R.string.phone_close, this::dismiss));
        content.addView(heading);

        LinearLayout tabs = new LinearLayout(context);
        channelTab = action(R.id.phone_world_channels, R.string.phone_world_channels, () -> showMode(false));
        programTab = action(R.id.phone_world_programs, R.string.phone_world_programs, () -> showMode(true));
        tabs.addView(channelTab, new LinearLayout.LayoutParams(0, -2, 1));
        tabs.addView(programTab, new LinearLayout.LayoutParams(0, -2, 1));
        content.addView(tabs);

        LinearLayout input = new LinearLayout(context);
        input.setGravity(Gravity.CENTER_VERTICAL);
        query = new EditText(context);
        query.setId(R.id.phone_world_query);
        query.setTextColor(Color.WHITE);
        query.setHintTextColor(MUTED);
        query.setTextSize(15);
        query.setSingleLine(true);
        query.setFilters(new InputFilter[]{new InputFilter.LengthFilter(100)});
        query.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        query.setPadding(dp(content, 11), 0, dp(content, 9), 0);
        query.setBackgroundDrawable(rounded(context, TILE, 11));
        query.setOnEditorActionListener((view, id, event) -> {
            if (id != EditorInfo.IME_ACTION_SEARCH) return false;
            search();
            return true;
        });
        query.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence text, int start, int count, int after) { }
            public void onTextChanged(CharSequence text, int start, int before, int count) {
                if (!programs) renderChannels();
            }
            public void afterTextChanged(Editable text) { }
        });
        input.addView(query, new LinearLayout.LayoutParams(0, dp(content, 48), 1));
        input.addView(action(R.id.phone_world_submit, R.string.phone_world_search, this::search));
        content.addView(input);

        filters = new LinearLayout(context);
        countryButton = action(R.id.phone_world_country, R.string.phone_world_all, this::chooseCountry);
        countryButton.setGravity(Gravity.CENTER_VERTICAL);
        filters.addView(countryButton, new LinearLayout.LayoutParams(0, -2, 1));
        refresh = action(R.id.phone_world_update, R.string.phone_world_update, () -> loadCatalog(true));
        filters.addView(refresh);
        content.addView(filters);

        status = label(context, 12, MUTED);
        status.setId(R.id.phone_world_status);
        content.addView(status);
        ListView results = new ListView(context);
        results.setId(R.id.phone_world_results);
        results.setDivider(new ColorDrawable(LINE));
        results.setDividerHeight(dp(content, 1));
        results.setAdapter(adapter);
        results.setOnItemClickListener((list, row, position, id) -> adapter.getItem(position).open.run());
        content.addView(results, new LinearLayout.LayoutParams(-1, 0, 1));

        credit = action(R.id.phone_world_credit, R.string.phone_world_iptv_credit, () -> openWeb(programs
                ? "https://www.tvmaze.com/api#licensing" : "https://github.com/iptv-org/iptv"));
        credit.setTextSize(11);
        credit.setGravity(Gravity.CENTER_VERTICAL);
        credit.setMinHeight(dp(content, 38));
        content.addView(credit);
        setContentView(content);
        content.requestFocus();
        showMode(false);
        loadCatalog(false);
    }

    @Override protected void onStart() {
        super.onStart();
        updateWindowSize();
    }

    void updateWindowSize() {
        Window window = getWindow();
        if (window == null || content == null) return;
        android.util.DisplayMetrics display = getContext().getResources().getDisplayMetrics();
        window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
                | WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN);
        window.setLayout(Math.min(display.widthPixels - dp(content, 20), dp(content, 650)),
                Math.min(display.heightPixels - dp(content, 24), dp(content, 690)));
        if (countryDialog != null && countryDialog.isShowing()) countryDialog.updateWindowSize();
    }

    private TextView action(int id, int text, Runnable choice) {
        TextView item = label(getContext(), 14, ACCENT);
        item.setId(id);
        item.setText(text);
        item.setGravity(Gravity.CENTER);
        item.setPadding(dp(content, 10), 0, dp(content, 10), 0);
        item.setMinHeight(dp(content, 48));
        item.setFocusable(true);
        item.setOnClickListener(v -> choice.run());
        return item;
    }

    private void showMode(boolean programMode) {
        programs = programMode;
        programRequest++;
        channelTab.setBackgroundDrawable(rounded(getContext(), programs ? PANEL : TILE, 10));
        programTab.setBackgroundDrawable(rounded(getContext(), programs ? TILE : PANEL, 10));
        query.setHint(programs ? R.string.phone_world_program_query : R.string.phone_world_channel_query);
        filters.setVisibility(programs ? View.GONE : View.VISIBLE);
        credit.setText(programs ? R.string.phone_world_tvmaze_credit : R.string.phone_world_iptv_credit);
        if (programs) showResults(Collections.emptyList(), getContext().getText(R.string.phone_world_program_hint));
        else renderChannels();
    }

    private void loadCatalog(boolean update) {
        if (loadingCatalog) return;
        loadingCatalog = true;
        refresh.setEnabled(false);
        if (!programs) {
            status.setVisibility(View.VISIBLE);
            status.setText(update ? R.string.phone_world_updating : R.string.phone_world_loading);
        }
        Context app = getContext().getApplicationContext();
        new Thread(() -> {
            try {
                WorldChannelCatalog.Index next = update ? WorldChannelCatalog.refresh(app) : WorldChannelCatalog.load(app);
                content.post(() -> finishCatalog(next, false));
            } catch (Exception error) {
                AppLog.w("WorldBrowser", "Could not load channel directory", error);
                content.post(() -> finishCatalog(null, true));
            }
        }, "world-tv-directory").start();
    }

    private void finishCatalog(WorldChannelCatalog.Index next, boolean failed) {
        if (!isShowing()) return;
        loadingCatalog = false;
        refresh.setEnabled(true);
        if (next != null) catalog = next;
        if (!programs) {
            renderChannels();
            if (failed) {
                status.setVisibility(View.VISIBLE);
                status.setText(R.string.phone_world_update_error);
            }
        }
    }

    private void chooseCountry() {
        if (catalog == null) return;
        hideKeyboard();
        ArrayList<String> codes = new ArrayList<>(catalog.countries);
        Collator sorting = Collator.getInstance(locale);
        Collections.sort(codes, (a, b) -> sorting.compare(region(a), region(b)));
        codes.add(0, "");
        List<SearchableChoiceDialog.Choice> choices = new ArrayList<>();
        for (int i = 0; i < codes.size(); i++) {
            String code = codes.get(i), label = region(code);
            choices.add(new SearchableChoiceDialog.Choice(i, label,
                    label + " " + WorldChannelCatalog.countrySearchText(code)));
        }
        countryDialog = new SearchableChoiceDialog(getContext(), getContext().getText(R.string.phone_world_all),
                choices, Math.max(0, codes.indexOf(country)), index -> {
                    country = codes.get(index);
                    renderChannels();
                });
        countryDialog.show();
    }

    private void renderChannels() {
        countryButton.setText(region(country));
        if (catalog == null) {
            showResults(Collections.emptyList(), getContext().getText(R.string.phone_world_loading));
            return;
        }
        if (!country.isEmpty() && !catalog.countries.contains(country)) country = "";
        String words = query.getText().toString().trim();
        ArrayList<Result> rows = new ArrayList<>();
        for (WorldChannelCatalog.Station entry : catalog.search(words, country, locale)) {
            rows.add(new Result(entry.name, WorldChannelCatalog.countryName(entry.country, locale), () -> openStation(entry)));
        }
        CharSequence info = rows.isEmpty() ? getContext().getText(R.string.phone_world_empty)
                : words.isEmpty() && country.isEmpty() ? getContext().getString(R.string.phone_world_count,
                        catalog.stations.size(), catalog.countries.size()) : "";
        showResults(rows, info);
    }

    private void openStation(WorldChannelCatalog.Station entry) {
        if (entry.lines.size() == 1) { play(entry, 0); return; }
        CharSequence[] names = new CharSequence[entry.lines.size()];
        for (int i = 0; i < entry.lines.size(); i++) {
            WorldChannelCatalog.Line line = entry.lines.get(i);
            String text = line.title.isEmpty() ? getContext().getString(R.string.phone_world_line, i + 1) : line.title;
            names[i] = line.regional ? text + " · " + getContext().getString(R.string.phone_world_regional) : text;
        }
        hideKeyboard();
        PhonePlayerControls.dialog(getContext()).setTitle(entry.name)
                .setItems(names, (dialog, line) -> play(entry, line))
                .setNegativeButton(R.string.phone_close, null).show();
    }

    private void play(WorldChannelCatalog.Station entry, int index) {
        dismiss();
        host.play(entry, entry.lines.get(index));
    }

    private String region(String code) {
        return code.isEmpty() ? getContext().getString(R.string.phone_world_all)
                : WorldChannelCatalog.countryName(code, locale);
    }

    private void search() {
        hideKeyboard();
        if (!programs) { renderChannels(); return; }
        String words = query.getText().toString().trim();
        if (words.isEmpty()) {
            showResults(Collections.emptyList(), getContext().getText(R.string.phone_world_program_hint));
            return;
        }
        List<Result> local = host.programs(words);
        showResults(local, getContext().getText(R.string.phone_world_program_loading));
        int request = ++programRequest;
        new Thread(() -> {
            ArrayList<Result> found = new ArrayList<>(local);
            boolean failed = false;
            try { appendTvmaze(words, found); }
            catch (Exception error) {
                failed = true;
                AppLog.w("WorldBrowser", "Could not load TV programme information", error);
            }
            boolean unavailable = failed;
            content.post(() -> {
                if (!isShowing() || !programs || request != programRequest) return;
                int text = unavailable ? R.string.phone_world_program_error : found.isEmpty() ? R.string.phone_world_empty : 0;
                showResults(found, text == 0 ? "" : getContext().getText(text));
            });
        }, "world-tv-programs").start();
    }

    private void appendTvmaze(String words, List<Result> rows) throws Exception {
        ByteArrayOutputStream response = new ByteArrayOutputStream();
        WorldChannelCatalog.fetch("https://api.tvmaze.com/search/shows?q=" + URLEncoder.encode(words, "UTF-8"),
                response, 2 * 1024 * 1024);
        JSONArray candidates = new JSONArray(response.toString("UTF-8"));
        for (int i = 0; i < Math.min(60, candidates.length()); i++) {
            JSONObject result = candidates.optJSONObject(i);
            JSONObject show = result == null ? null : result.optJSONObject("show");
            if (show == null) continue;
            String name = string(show, "name"), url = string(show, "url");
            Uri link = Uri.parse(url);
            if (name.isEmpty() || !"https".equals(link.getScheme())
                    || !("www.tvmaze.com".equals(link.getHost()) || "tvmaze.com".equals(link.getHost()))
                    || link.getPath() == null || !link.getPath().startsWith("/shows/")) continue;
            JSONObject network = show.optJSONObject("network");
            if (network == null) network = show.optJSONObject("webChannel");
            String premiered = string(show, "premiered");
            String broadcaster = network == null ? "" : string(network, "name");
            String detail = getContext().getString(R.string.phone_world_show_info);
            if (!broadcaster.isEmpty()) detail += " · " + broadcaster;
            if (premiered.length() >= 4) detail += " · " + premiered.substring(0, 4);
            rows.add(new Result(name, detail, () -> openWeb(url)));
        }
    }

    private static String string(JSONObject object, String key) {
        return object.isNull(key) ? "" : object.optString(key, "");
    }

    private void openWeb(String address) {
        try { getContext().startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(address))); }
        catch (ActivityNotFoundException unavailable) {
            Toast.makeText(getContext(), R.string.phone_world_program_error, Toast.LENGTH_SHORT).show();
        }
    }

    private void hideKeyboard() {
        InputMethodManager keyboard = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
        if (keyboard != null && query != null) keyboard.hideSoftInputFromWindow(query.getWindowToken(), 0);
    }

    @Override public void dismiss() {
        if (countryDialog != null) countryDialog.dismiss();
        hideKeyboard();
        super.dismiss();
    }

    private void showResults(List<Result> rows, CharSequence message) {
        adapter.rows = rows;
        adapter.notifyDataSetChanged();
        status.setText(message);
        status.setVisibility(message.length() == 0 ? View.GONE : View.VISIBLE);
    }

    private final class Rows extends BaseAdapter {
        List<Result> rows = Collections.emptyList();

        @Override public int getCount() { return rows.size(); }
        @Override public Result getItem(int position) { return rows.get(position); }
        @Override public long getItemId(int position) { return position; }

        @Override public View getView(int position, View recycled, ViewGroup parent) {
            Row row = recycled instanceof Row ? (Row) recycled : new Row(getContext());
            Result result = getItem(position);
            row.title.setText(result.name);
            row.detail.setText(result.detail);
            row.detail.setVisibility(result.detail.isEmpty() ? View.GONE : View.VISIBLE);
            return row;
        }
    }

    private static final class Row extends LinearLayout {
        final TextView title, detail;

        Row(Context context) {
            super(context);
            setOrientation(VERTICAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setMinimumHeight(dp(this, 55));
            setPadding(dp(this, 10), dp(this, 4), dp(this, 10), dp(this, 4));
            title = label(context, 16, Color.WHITE);
            title.setMaxLines(2);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            detail = label(context, 12, MUTED);
            detail.setSingleLine(true);
            detail.setEllipsize(android.text.TextUtils.TruncateAt.END);
            addView(title);
            addView(detail);
        }
    }
}
