package xiao.bu.tv;

import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Phone player controls dock in portrait and overlay the player in full screen. */
@SuppressWarnings("deprecation")
final class PhonePlayerControls extends LinearLayout {
    static final int PANEL = 0xff101b2c;
    static final int TILE = 0xff1b2b41;
    static final int LINE = 0xff3b526b;
    static final int ACCENT = 0xffa9f7e5;
    static final int MUTED = 0xffc0d3e4;
    private static final int RECORDING = 0xffffb0c6;

    private final LinearLayout channel;
    private final LinearLayout buttons;
    private final LinearLayout content;
    private final TextView recordButton;
    private final TextView fullscreenButton;
    private final TextView scaleButton;
    private final TextView channelName;
    private final TextView status;
    private final PhonePlaybackTimeline timeline;
    private Boolean wide;

    PhonePlayerControls(Context context, Runnable pick, Runnable previous, Runnable next,
            Runnable menu, Runnable screenshot, Runnable record, Runnable replay, Runnable world,
            Runnable fullscreen, Runnable scale, PhonePlaybackTimeline.Listener timelineListener) {
        super(context);
        setId(R.id.phone_controls);
        setGravity(Gravity.CENTER_VERTICAL);
        setOrientation(VERTICAL);
        setPadding(dp(this, 12), dp(this, 6), dp(this, 12), dp(this, 9));
        setBackgroundColor(PANEL);
        setClickable(true);

        timeline = new PhonePlaybackTimeline(context, timelineListener);
        timeline.setVisibility(GONE);
        addView(timeline, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
        content = new LinearLayout(context);
        content.setGravity(Gravity.CENTER_VERTICAL);
        addView(content, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        channel = new LinearLayout(context);
        channel.setGravity(Gravity.CENTER_VERTICAL);
        ImageView mascot = new ImageView(context);
        mascot.setImageResource(R.mipmap.ic_launcher);
        if (android.os.Build.VERSION.SDK_INT >= 16) mascot.setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        channel.addView(mascot, new LayoutParams(dp(this, 38), dp(this, 38)));
        LinearLayout details = new LinearLayout(context);
        details.setOrientation(VERTICAL);
        details.setPadding(dp(this, 8), 0, dp(this, 5), dp(this, 2));
        channel.addView(details, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
        TextView caption = label(context, 11, ACCENT);
        caption.setText(R.string.phone_current_channel);
        details.addView(caption);
        channelName = label(context, 19, Color.WHITE);
        channelName.setId(R.id.phone_current_title);
        channelName.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        channelName.setMaxLines(1);
        channelName.setEllipsize(TextUtils.TruncateAt.END);
        details.addView(channelName);
        status = label(context, 11, MUTED);
        status.setId(R.id.phone_current_status);
        status.setMaxLines(1);
        status.setEllipsize(TextUtils.TruncateAt.END);
        details.addView(status);
        content.addView(channel);

        buttons = new LinearLayout(context);
        buttons.setOrientation(VERTICAL);
        content.addView(buttons);
        LinearLayout tools = new LinearLayout(context);
        tools.setBaselineAligned(false);
        addTool(tools, R.id.phone_replay, R.string.phone_replay, "↶", replay);
        addTool(tools, R.id.phone_screenshot, R.string.phone_screenshot, "◎", screenshot);
        recordButton = addTool(tools, R.id.phone_record, R.string.phone_record, "●", record);
        recordButton.setVisibility(android.os.Build.VERSION.SDK_INT >= 21 ? VISIBLE : GONE);
        fullscreenButton = addTool(tools, R.id.phone_fullscreen, R.string.phone_fullscreen, "", fullscreen);
        scaleButton = addTool(tools, R.id.phone_scale, R.string.phone_fill_screen, "", scale);
        scaleButton.setVisibility(GONE);
        buttons.addView(tools, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout actions = new LinearLayout(context);
        actions.setBaselineAligned(false);
        actions.setGravity(Gravity.CENTER_VERTICAL);
        addAction(actions, R.id.phone_pick, R.string.phone_pick, true, pick);
        addAction(actions, R.id.phone_previous, R.string.phone_previous, false, previous);
        addAction(actions, R.id.phone_next, R.string.phone_next, false, next);
        addAction(actions, R.id.phone_world, R.string.phone_world, false, world);
        addAction(actions, R.id.phone_menu, R.string.phone_menu, false, menu);
        LayoutParams actionLayout = new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        actionLayout.topMargin = dp(this, 5);
        buttons.addView(actions, actionLayout);
        bind("", "");
    }

    private TextView addTool(LinearLayout row, int id, int resource, String symbol, Runnable action) {
        TextView tool = label(getContext(), 12, MUTED);
        tool.setId(id);
        tool.setGravity(Gravity.CENTER);
        tool.setMinimumHeight(dp(this, 48));
        tool.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tool.setFocusable(true);
        tool.setOnClickListener(view -> action.run());
        tool.setBackgroundDrawable(actionBackground(getContext(), false));
        setToolLabel(tool, resource, symbol);
        LayoutParams params = new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1);
        if (row.getChildCount() > 0) params.leftMargin = dp(this, 6);
        row.addView(tool, params);
        return tool;
    }

    private void setToolLabel(TextView tool, int resource, String symbol) {
        CharSequence name = getContext().getText(resource);
        tool.setText(symbol.isEmpty() ? name : symbol + " " + name);
        tool.setContentDescription(name);
    }

    void bindRecording(boolean recording, boolean busy) {
        recordButton.setEnabled(!busy);
        setToolLabel(recordButton, recording ? R.string.phone_record_stop
                : busy ? R.string.phone_record_wait : R.string.phone_record, recording ? "■" : "●");
        recordButton.setTextColor(recording ? PANEL : MUTED);
        recordButton.setBackgroundDrawable(recording ? rounded(getContext(), RECORDING, 15)
                : actionBackground(getContext(), false));
    }

    private void addAction(LinearLayout actions, int id, int label, boolean primary, Runnable action) {
        Context context = getContext();
        TextView tile = label(context, 12, primary ? PANEL : Color.WHITE);
        tile.setId(id);
        tile.setText(label);
        tile.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        tile.setMaxLines(2);
        tile.setGravity(Gravity.CENTER);
        tile.setMinimumHeight(dp(this, 48));
        tile.setPadding(dp(this, 3), dp(this, 3), dp(this, 3), dp(this, 4));
        tile.setContentDescription(context.getString(label));
        tile.setFocusable(true);
        tile.setOnClickListener(view -> action.run());
        tile.setBackgroundDrawable(actionBackground(context, primary));
        LayoutParams params = new LayoutParams(0, LayoutParams.WRAP_CONTENT, primary ? 1.22f : 1f);
        if (actions.getChildCount() > 0) params.leftMargin = dp(this, 6);
        actions.addView(tile, params);
    }

    void setImmersive(boolean immersive, boolean fill) {
        setBackgroundColor(immersive ? 0xeb101b2c : PANEL);
        setToolLabel(fullscreenButton, immersive ? R.string.phone_exit_fullscreen : R.string.phone_fullscreen, "");
        scaleButton.setVisibility(immersive ? VISIBLE : GONE);
        setToolLabel(scaleButton, fill ? R.string.phone_fit_screen : R.string.phone_fill_screen, "");
    }

    void setSafeInsets(int left, int right, int bottom) {
        setPadding(dp(this, 12) + left, dp(this, 6), dp(this, 12) + right, dp(this, 9) + bottom);
    }

    boolean timelineVisible() { return getVisibility() == VISIBLE && timeline.getVisibility() == VISIBLE; }
    boolean scrubbing() { return timeline.dragging(); }
    void showTimeline(boolean show) { timeline.setVisibility(show ? VISIBLE : GONE); }
    void bindTimeline(PhonePlaybackTimeline.Range range) { timeline.bind(range); }

    private static StateListDrawable actionBackground(Context context, boolean primary) {
        StateListDrawable colors = new StateListDrawable();
        colors.addState(new int[]{android.R.attr.state_pressed}, rounded(context, primary ? 0xff9fe7d1 : LINE, 15));
        colors.addState(new int[]{android.R.attr.state_focused}, rounded(context, primary ? 0xffe0fff5 : LINE, 15));
        colors.addState(new int[0], rounded(context, primary ? ACCENT : TILE, 15));
        return colors;
    }

    void bind(CharSequence name, CharSequence message) {
        CharSequence title = TextUtils.isEmpty(name) ? getContext().getText(R.string.phone_no_channel) : name;
        if (!TextUtils.equals(channelName.getText(), title)) channelName.setText(title);
        boolean hasStatus = !TextUtils.isEmpty(message);
        status.setVisibility(hasStatus ? VISIBLE : GONE);
        if (hasStatus && !TextUtils.equals(status.getText(), message)) status.setText(message);
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        boolean nextWide = MeasureSpec.getSize(widthSpec) >= dp(this, 580);
        if (wide == null || wide != nextWide) {
            wide = nextWide;
            content.setOrientation(nextWide ? HORIZONTAL : VERTICAL);
            channel.setLayoutParams(nextWide ? new LayoutParams(0, LayoutParams.WRAP_CONTENT, 0.74f)
                    : new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));
            LayoutParams controls = nextWide ? new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1.26f)
                    : new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
            if (nextWide) controls.leftMargin = dp(this, 13);
            else controls.topMargin = dp(this, 4);
            buttons.setLayoutParams(controls);
        }
        super.onMeasure(widthSpec, heightSpec);
    }

    static GradientDrawable rounded(Context context, int color, int radius) {
        GradientDrawable drawable = new GradientDrawable();
        drawable.setColor(color);
        drawable.setCornerRadius(radius * context.getResources().getDisplayMetrics().density);
        return drawable;
    }

    static AlertDialog.Builder dialog(Context context) {
        return android.os.Build.VERSION.SDK_INT >= 21
                ? new AlertDialog.Builder(context, R.style.PhoneDialogTheme)
                : new AlertDialog.Builder(context);
    }

    static TextView label(Context context, int size, int color) {
        TextView text = new TextView(context);
        text.setTextSize(size);
        text.setTextColor(color);
        text.setIncludeFontPadding(true);
        return text;
    }

    static int dp(android.view.View view, int value) {
        return Math.round(value * view.getResources().getDisplayMetrics().density);
    }
}
