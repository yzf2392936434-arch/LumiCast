package xiao.bu.tv;

import android.content.Context;
import android.content.res.ColorStateList;
import android.os.Build;
import android.text.TextUtils;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

/** The bottom progress bar uses a fixed snapshot until the user lifts their finger. */
final class PhonePlaybackTimeline extends LinearLayout {
    interface Listener {
        void seek(Range range, long position);
        void toggle();
        void live();
    }

    static final class Range {
        final String session;
        final Object archive;
        final long start, end, position;
        final boolean playable, playing, canReturnLive;

        Range(String session, Object archive, long start, long end, long position,
                boolean playable, boolean playing, boolean canReturnLive) {
            this.session = session;
            this.archive = archive;
            this.start = start;
            this.end = end;
            this.position = position;
            this.playable = playable;
            this.playing = playing;
            this.canReturnLive = canReturnLive;
        }

        boolean seekable() { return end > start; }
        boolean live() { return archive != null; }
    }

    private static final int STEPS = 1000;
    private final SeekBar seek;
    private final TextView position, end, pause, live;
    private final DateFormat localTime;
    private Range range;
    private boolean dragging;
    private boolean cancelled;

    PhonePlaybackTimeline(Context context, Listener listener) {
        super(context);
        setId(R.id.phone_timeline);
        setOrientation(VERTICAL);
        localTime = android.text.format.DateFormat.getTimeFormat(context);
        LinearLayout row = new LinearLayout(context);
        row.setGravity(Gravity.CENTER_VERTICAL);
        pause = PhonePlayerControls.label(context, 13, PhonePlayerControls.ACCENT);
        pause.setId(R.id.phone_toggle_playback);
        pause.setGravity(Gravity.CENTER);
        pause.setMinWidth(PhonePlayerControls.dp(this, 54));
        pause.setMinHeight(PhonePlayerControls.dp(this, 48));
        pause.setOnClickListener(view -> listener.toggle());
        row.addView(pause, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));

        seek = new SeekBar(context);
        seek.setId(R.id.phone_timeline_seek);
        seek.setContentDescription(context.getText(R.string.phone_playback_position));
        seek.setMax(STEPS);
        if (Build.VERSION.SDK_INT >= 21) {
            ColorStateList accent = ColorStateList.valueOf(PhonePlayerControls.ACCENT);
            seek.setProgressTintList(accent);
            seek.setThumbTintList(accent);
            seek.setProgressBackgroundTintList(ColorStateList.valueOf(PhonePlayerControls.LINE));
        }
        row.addView(seek, new LayoutParams(0, PhonePlayerControls.dp(this, 48), 1));
        live = PhonePlayerControls.label(context, 13, PhonePlayerControls.ACCENT);
        live.setText(R.string.phone_return_live);
        live.setGravity(Gravity.CENTER);
        live.setMinHeight(PhonePlayerControls.dp(this, 48));
        live.setPadding(PhonePlayerControls.dp(this, 8), 0, PhonePlayerControls.dp(this, 8), 0);
        live.setOnClickListener(view -> listener.live());
        live.setVisibility(GONE);
        row.addView(live, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        addView(row, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        LinearLayout labels = new LinearLayout(context);
        labels.setPadding(PhonePlayerControls.dp(this, 11), 0, PhonePlayerControls.dp(this, 16), 0);
        position = PhonePlayerControls.label(context, 12, PhonePlayerControls.MUTED);
        end = PhonePlayerControls.label(context, 12, PhonePlayerControls.MUTED);
        labels.addView(position, new LayoutParams(0, LayoutParams.WRAP_CONTENT, 1));
        labels.addView(end, new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT));
        addView(labels, new LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT));

        seek.setOnTouchListener((view, event) -> {
            cancelled = event.getActionMasked() == android.view.MotionEvent.ACTION_CANCEL;
            return false;
        });
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onStartTrackingTouch(SeekBar bar) { dragging = true; cancelled = false; }
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                if (!fromUser || range == null || !range.seekable()) return;
                long target = value(progress);
                showPosition(target);
                if (!dragging) listener.seek(range, target);
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                dragging = false;
                if (!cancelled && range != null && range.seekable()) listener.seek(range, value(bar.getProgress()));
            }
        });
    }

    boolean dragging() { return dragging; }

    void bind(Range next) {
        if (dragging) return;
        range = next;
        pause.setEnabled(next.playable);
        live.setVisibility(next.canReturnLive ? VISIBLE : GONE);
        setText(pause, getResources().getText(next.playing ? R.string.phone_pause : R.string.phone_play));
        seek.setEnabled(next.seekable());
        seek.setAlpha(next.seekable() ? 1f : 0.48f);
        int progress = next.seekable() ? (int) Math.max(0L, Math.min(STEPS,
                (next.position - next.start) * (double) STEPS / (next.end - next.start))) : 0;
        if (seek.getProgress() != progress) seek.setProgress(progress);
        showPosition(next.position);
        setText(end, next.live() ? getResources().getText(R.string.phone_live_edge)
                : next.seekable() ? stamp(next.end) : "");
    }

    private long value(int progress) {
        return range.start + Math.round((range.end - range.start) * (double) progress / STEPS);
    }

    private void showPosition(long value) {
        setText(position, range.live() ? localTime.format(new Date(value))
                : range.seekable() ? stamp(value) : getResources().getText(R.string.phone_timeline_unavailable));
    }

    private static void setText(TextView text, CharSequence value) {
        if (!TextUtils.equals(text.getText(), value)) text.setText(value);
    }

    private static String stamp(long time) {
        long seconds = Math.max(0, time) / 1000L;
        return seconds >= 3600 ? String.format(Locale.US, "%d:%02d:%02d", seconds / 3600, seconds / 60 % 60, seconds % 60)
                : String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60);
    }
}
