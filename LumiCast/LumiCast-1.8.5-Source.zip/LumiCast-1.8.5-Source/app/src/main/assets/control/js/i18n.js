(function () {
    'use strict';

    var dictionaries = {};
    var language = 'zh-CN';
    var attributes = ['aria-label', 'placeholder', 'title', 'alt'];
    var originals = typeof WeakMap === 'function' ? new WeakMap() : null;
    var has = Object.prototype.hasOwnProperty;

    function normalize(code) {
        var tag = String(code || '').toLowerCase().replace(/_/g, '-');
        var primary = tag.split('-')[0];
        if (primary === 'zh') {
            if (/(^|-)hant(-|$)/.test(tag)) return 'zh-TW';
            if (/(^|-)hans(-|$)/.test(tag)) return 'zh-CN';
            return /(^|-)(tw|hk|mo)(-|$)/.test(tag) ? 'zh-TW' : 'zh-CN';
        }
        if (primary === 'en' || primary === 'ja' || primary === 'ko') return primary;
        return '';
    }

    function browserLanguage() {
        var candidates = navigator.languages || [navigator.language || navigator.userLanguage];
        for (var i = 0; i < candidates.length; i++) {
            var value = normalize(candidates[i]);
            if (value) return value;
        }
        return 'zh-CN';
    }

    function translate(value) {
        var dictionary = dictionaries[language];
        if (!dictionary || !value) return value;
        if (has.call(dictionary, value)) return dictionary[value];
        var trimmed = value.trim().replace(/\s+/g, ' ');
        if (has.call(dictionary, trimmed)) {
            return value.replace(/^(\s*)[\s\S]*?(\s*)$/, '$1' + dictionary[trimmed] + '$2');
        }
        return value;
    }

    function record(node) {
        if (!originals) return node.ntvLocaleOriginals || (node.ntvLocaleOriginals = {});
        if (!originals.has(node)) originals.set(node, {});
        return originals.get(node);
    }

    function update(node, attribute) {
        var current = attribute ? node.getAttribute(attribute) : node.nodeValue;
        if (!current || !current.trim()) return;
        var key = attribute || '#text';
        var previous = originals ? originals.get(node) : node.ntvLocaleOriginals;
        var entry = previous && previous[key];
        var original = entry && entry.result === current ? entry.source : current;
        var next = translate(original);
        if (next === current) return;
        record(node)[key] = {source: original, result: next};
        if (attribute) node.setAttribute(attribute, next);
        else node.nodeValue = next;
    }

    function localize(root) {
        if (!root) return;
        if (root.nodeType === 3) {
            var parent = root.parentNode;
            if (!parent || /^(SCRIPT|STYLE|TEXTAREA)$/.test(parent.nodeName)
                    || (parent.nodeName === 'OPTION' && !parent.hasAttribute('value'))) return;
            update(root);
            return;
        }
        if (root.nodeType !== 1 || /^(SCRIPT|STYLE|TEXTAREA)$/.test(root.nodeName)) return;
        for (var index = 0; index < attributes.length; index++) {
            if (root.hasAttribute(attributes[index])) update(root, attributes[index]);
        }
        for (var child = root.firstChild; child; child = child.nextSibling) localize(child);
    }

    function setLanguage(code) {
        var target = normalize(code) || browserLanguage();
        if (target === language) return;
        language = target;
        document.documentElement.lang = target;
        localize(document.documentElement);
    }

    window.NtvI18n = {use: setLanguage, text: translate};
    setLanguage(browserLanguage());

    var request = new XMLHttpRequest();
    request.open('GET', '/locales.json', true);
    request.onreadystatechange = function () {
        if (request.readyState !== 4 || request.status !== 200) return;
        try {
            dictionaries = JSON.parse(request.responseText);
        } catch (error) {
            return;
        }
        localize(document.documentElement);
        if (window.MutationObserver) {
            new MutationObserver(function (entries) {
                entries.forEach(function (entry) {
                    if (entry.type === 'childList') {
                        Array.prototype.forEach.call(entry.addedNodes, localize);
                    } else if (entry.type === 'characterData') {
                        localize(entry.target);
                    } else {
                        update(entry.target, entry.attributeName);
                    }
                });
            }).observe(document.documentElement, {
                childList: true, characterData: true, subtree: true,
                attributes: true, attributeFilter: attributes
            });
        }
    };
    request.send(null);
})();
